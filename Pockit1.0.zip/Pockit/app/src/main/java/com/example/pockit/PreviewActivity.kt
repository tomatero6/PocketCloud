package com.example.pockit

import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.MediaController
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import coil.load
import com.example.pockit.databinding.ActivityPreviewBinding

class PreviewActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPreviewBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPreviewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val url = intent.getStringExtra("url") ?: return finish()
        val name = intent.getStringExtra("name") ?: ""
        val isVideo = intent.getBooleanExtra("isVideo", false)

        binding.btnClose.setOnClickListener { finish() }
        
        binding.btnRotate.setOnClickListener {
            requestedOrientation = if (requestedOrientation == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) {
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            } else {
                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            }
        }

        if (isVideo) {
            showVideo(url)
        } else {
            showImage(url)
        }
    }

    private fun showImage(url: String) {
        binding.ivPreview.visibility = View.VISIBLE
        binding.pbLoading.visibility = View.VISIBLE
        binding.ivPreview.load(url) {
            listener(
                onSuccess = { _, _ -> binding.pbLoading.visibility = View.GONE },
                onError = { _, _ -> 
                    binding.pbLoading.visibility = View.GONE
                    Toast.makeText(this@PreviewActivity, "加载图片失败", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }

    private fun showVideo(url: String) {
        binding.vvPreview.visibility = View.VISIBLE
        binding.pbLoading.visibility = View.VISIBLE
        
        val mediaController = MediaController(this)
        mediaController.setAnchorView(binding.vvPreview)
        binding.vvPreview.setMediaController(mediaController)
        binding.vvPreview.setVideoURI(Uri.parse(url))
        
        binding.vvPreview.setOnPreparedListener { 
            binding.pbLoading.visibility = View.GONE
            it.start()
        }
        
        binding.vvPreview.setOnErrorListener { _, _, _ ->
            binding.pbLoading.visibility = View.GONE
            Toast.makeText(this, "播放视频失败", Toast.LENGTH_SHORT).show()
            true
        }
    }
}
