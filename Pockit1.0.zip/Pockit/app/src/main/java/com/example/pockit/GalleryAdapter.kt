package com.example.pockit

import android.net.Uri
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.pockit.databinding.ItemMediaBinding
import java.io.File

sealed class GalleryItem {
    data class Local(val media: LocalMediaFile, var isSelected: Boolean = false, var isBackedUp: Boolean = false) : GalleryItem()
    data class RemoteAlbum(val album: Album) : GalleryItem()
    data class RemotePhoto(val file: RemoteFile) : GalleryItem()
}

class GalleryAdapter(
    private val getBaseUrl: () -> String,
    private val onSelectionChanged: () -> Unit,
    private val onAlbumClick: (Album) -> Unit,
    private val onItemClick: (GalleryItem) -> Unit,
    private val onLongClick: (Int) -> Boolean
) : RecyclerView.Adapter<GalleryAdapter.ViewHolder>() {

    var items: List<GalleryItem> = emptyList()
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    class ViewHolder(val binding: ItemMediaBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemMediaBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        
        holder.binding.apply {
            cbSelect.setOnCheckedChangeListener(null)
            root.setOnClickListener(null)
            root.setOnLongClickListener(null)
            ivFolderIcon.visibility = View.GONE
            ivInCloud.visibility = View.GONE

            root.foreground = null

            when (item) {
                is GalleryItem.Local -> {
                    tvTitle.text = item.media.name
                    ivThumbnail.load(File(item.media.path)) {
                        crossfade(true)
                        size(300, 300)
                        placeholder(android.R.drawable.ic_menu_gallery)
                    }
                    cbSelect.visibility = View.VISIBLE
                    cbSelect.isChecked = item.isSelected
                    ivInCloud.visibility = if (item.isBackedUp) View.VISIBLE else View.GONE
                    
                    root.alpha = if (item.isSelected) 0.6f else 1.0f
                    
                    cbSelect.setOnCheckedChangeListener { _, isChecked ->
                        item.isSelected = isChecked
                        root.alpha = if (isChecked) 0.6f else 1.0f
                        onSelectionChanged()
                    }
                    
                    root.setOnClickListener {
                        onItemClick(item)
                    }
                    
                    root.setOnLongClickListener {
                        // 使用适配兼容的 adapterPosition
                        val currentPos = holder.adapterPosition
                        if (currentPos != RecyclerView.NO_POSITION) {
                            onLongClick(currentPos)
                        } else {
                            false
                        }
                    }
                }
                
                is GalleryItem.RemoteAlbum -> {
                    tvTitle.text = "${item.album.name} (${item.album.count})"
                    cbSelect.visibility = View.GONE
                    ivFolderIcon.visibility = View.VISIBLE
                    root.alpha = 1.0f
                    
                    val baseUrl = getBaseUrl()
                    if (!item.album.firstImagePath.isNullOrEmpty() && baseUrl.isNotEmpty()) {
                        val encodedPath = Uri.encode(item.album.firstImagePath)
                        val thumbUrl = "$baseUrl/api/thumbnail?path=$encodedPath&size=300"
                        
                        ivThumbnail.load(thumbUrl) {
                            crossfade(true)
                            placeholder(android.R.drawable.ic_menu_gallery)
                        }
                    } else {
                        ivThumbnail.setImageResource(android.R.drawable.ic_menu_gallery)
                    }
                    root.setOnClickListener { onAlbumClick(item.album) }
                }

                is GalleryItem.RemotePhoto -> {
                    tvTitle.text = item.file.name
                    cbSelect.visibility = View.GONE
                    ivInCloud.visibility = View.VISIBLE
                    root.alpha = 1.0f

                    val baseUrl = getBaseUrl()
                    if (baseUrl.isNotEmpty()) {
                        val encodedPath = Uri.encode(item.file.path)
                        val thumbUrl = "$baseUrl/api/thumbnail?path=$encodedPath&size=300"
                        
                        ivThumbnail.load(thumbUrl) {
                            crossfade(true)
                            placeholder(android.R.drawable.ic_menu_gallery)
                            error(android.R.drawable.ic_menu_report_image)
                        }
                    }
                    root.setOnClickListener { onItemClick(item) }
                }
            }
        }
    }

    override fun getItemCount() = items.size
}
