package com.example.pockit

import okhttp3.MultipartBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

interface PockyService {
    // 1.1 获取存储卷列表
    @GET("/api/volumes")
    suspend fun getVolumes(): List<Volume>

    // 1.2 获取相册列表
    @GET("/api/albums")
    suspend fun getAlbums(): List<Album>

    // 1.3 获取文件列表 (通用浏览器)
    @GET("/api/files")
    suspend fun getFiles(@Query("path") path: String? = null): List<RemoteFile>

    // 2.1 获取目录下照片
    @GET("/api/photos")
    suspend fun getPhotos(@Query("path") path: String): List<RemoteFile>

    // 2.2 获取缩略图 (专门用于照片墙预览)
    @GET("/api/thumbnail")
    @Streaming
    suspend fun getThumbnail(
        @Query("path") path: String,
        @Query("size") size: Int = 300
    ): Response<ResponseBody>

    // 2.3 查看/预览原文件 (支持 Range 请求)
    @GET("/api/view")
    @Streaming
    suspend fun viewFile(@Query("path") path: String): Response<ResponseBody>

    // 3.1 检查上传状态
    @GET("/api/upload/status")
    suspend fun getUploadStatus(
        @Query("path") path: String,
        @Query("name") name: String
    ): UploadStatus

    // 3.2 上传文件 (Multipart)
    @Multipart
    @POST("/api/upload")
    suspend fun uploadFile(
        @Query("path") path: String,
        @Query("offset") offset: Long,
        @Part file: MultipartBody.Part
    ): Response<UploadResponse>

    // 3.3 下载文件
    @GET("/api/download")
    @Streaming
    suspend fun downloadFile(@Query("path") path: String): Response<ResponseBody>

    // 3.4 删除文件/文件夹
    @DELETE("/api/delete")
    suspend fun deleteFile(@Query("path") path: String): GenericResponse

    // 3.5 创建文件夹 (递归创建/确保目录存在)
    @POST("/api/mkdir")
    suspend fun makeDirectory(
        @Query("path") path: String,
        @Query("name") name: String
    ): GenericResponse

    // 3.6 复制文件/文件夹
    @POST("/api/copy")
    suspend fun copyFiles(
        @Query("from") fromPaths: List<String>,
        @Query("to") toPath: String
    ): GenericResponse

    // 3.7 移动文件/文件夹
    @POST("/api/move")
    suspend fun moveFiles(
        @Query("from") fromPaths: List<String>,
        @Query("to") toPath: String
    ): GenericResponse

    // 3.8 重命名
    @POST("/api/rename")
    suspend fun renameFile(
        @Query("path") path: String,
        @Query("newName") newName: String
    ): GenericResponse

    // 3.9 压缩 (Zip)
    @POST("/api/zip")
    suspend fun zipFiles(
        @Query("from") fromPaths: List<String>,
        @Query("to") toPath: String
    ): GenericResponse

    // 3.10 解压 (Unzip)
    @POST("/api/unzip")
    suspend fun unzipFile(@Query("path") path: String): GenericResponse

    // 4.1 在服务器上播放音乐
    @POST("/api/play-on-server")
    suspend fun playOnServer(@Query("path") path: String): GenericResponse

    // 4.2 播放器/音量控制
    @POST("/api/player-control")
    suspend fun controlPlayer(@Query("action") action: String): GenericResponse
}
