package com.example.pockit

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed class BackupState {
    object Idle : BackupState()
    data class Running(val status: String, val detail: String, val progress: Int, val isPaused: Boolean) : BackupState()
}

class MainViewModel : ViewModel() {
    private val _baseUrl = MutableStateFlow("")
    val baseUrl: StateFlow<String> = _baseUrl

    private val _service = MutableStateFlow<PockyService?>(null)
    val service: StateFlow<PockyService?> = _service

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected

    private val _primaryVolume = MutableStateFlow<Volume?>(null)
    val primaryVolume: StateFlow<Volume?> = _primaryVolume

    private val _backupState = MutableStateFlow<BackupState>(BackupState.Idle)
    val backupState: StateFlow<BackupState> = _backupState

    fun setConnection(ip: String) {
        val url = if (ip.startsWith("http")) {
            if (ip.endsWith("/")) ip.dropLast(1) else ip
        } else {
            "http://$ip:9000"
        }
        _baseUrl.value = url
        val newService = PockyClient.createService(url)
        _service.value = newService
        
        viewModelScope.launch {
            try {
                val volumes = newService.getVolumes()
                _primaryVolume.value = volumes.find { it.isPrimary } ?: volumes.firstOrNull()
                _isConnected.value = true
            } catch (e: Exception) {
                _isConnected.value = false
            }
        }
    }

    fun updateBackupState(state: BackupState) {
        _backupState.value = state
    }
}
