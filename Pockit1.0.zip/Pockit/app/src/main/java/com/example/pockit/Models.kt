@file:OptIn(kotlinx.serialization.ExperimentalSerializationApi::class)

package com.example.pockit

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonNames

@Serializable
data class Volume(
    val name: String,
    val path: String,
    val isPrimary: Boolean,
    
    @JsonNames("totalSize", "total_size")
    val totalSize: Long = 0,

    @JsonNames("availableSize", "available_size", "free")
    val availableSize: Long = 0,

    val hardwareSizeGB: Int = 0
) {
    val usedSize: Long get() = (totalSize - availableSize).coerceAtLeast(0)
}

@Serializable
data class Album(
    val name: String = "",
    @JsonNames("fullPath", "path")
    val path: String = "",
    val firstImagePath: String? = null,
    val count: Int = 0
) {
    val realPath: String get() = path
}

@Serializable
data class RemoteFile(
    val name: String? = null,
    @JsonNames("fullPath", "path")
    val path: String = "",
    @JsonNames("isDirectory", "isDir", "dir")
    val isDir: Boolean = false,
    val size: Long = 0,
    val modificationTime: Long = 0
) {
    val realPath: String get() = path
}

@Serializable
data class UploadStatus(
    val size: Long,
    val md5: String? = null
)

@Serializable
data class GenericResponse(
    val success: Boolean,
    val message: String? = null,
    val existed: Boolean? = null
)

@Serializable
data class UploadResponse(
    val success: Boolean,
    val count: Int = 0,
    val error: String? = null
)
