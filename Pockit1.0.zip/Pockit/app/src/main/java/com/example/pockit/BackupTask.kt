package com.example.pockit

import java.io.File

data class BackupTask(
    val localFile: File,
    val remotePath: String, // e.g., "Pixel_7/2023/10"
    val remoteFileName: String, // Original filename
    var status: TaskStatus = TaskStatus.PENDING,
    var uploadedSize: Long = 0
)

enum class TaskStatus {
    PENDING,
    UPLOADING,
    COMPLETED,
    FAILED
}
