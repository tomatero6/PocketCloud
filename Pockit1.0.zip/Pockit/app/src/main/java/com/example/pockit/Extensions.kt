package com.example.pockit

import android.net.Uri
import java.util.Locale

fun Long.formatSize(): String {
    if (this <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (Math.log10(this.toDouble()) / Math.log10(1024.0)).toInt()
    return String.format(Locale.getDefault(), "%.1f %s", this / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
}

fun Long.formatSizeGB(): String {
    return String.format(Locale.getDefault(), "%.2fG", this.toDouble() / (1024 * 1024 * 1024))
}

fun String.isImageFile(): Boolean {
    val lower = this.lowercase()
    return lower.endsWith(".jpg") || lower.endsWith(".png") || lower.endsWith(".webp") || lower.endsWith(".jpeg")
}

fun String.isVideoFile(): Boolean {
    val lower = this.lowercase()
    return lower.endsWith(".mp4") || lower.endsWith(".mkv") || lower.endsWith(".avi") || lower.endsWith(".mov")
}

fun String.isAudioFile(): Boolean {
    val lower = this.lowercase()
    return lower.endsWith(".mp3") || lower.endsWith(".flac") || lower.endsWith(".wav") || lower.endsWith(".m4a")
}

fun String.isZipFile(): Boolean {
    return this.lowercase().endsWith(".zip")
}

fun String.urlEncode(): String = Uri.encode(this)
