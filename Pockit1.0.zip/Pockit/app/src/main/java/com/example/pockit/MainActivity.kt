package com.example.pockit

import android.Manifest
import android.app.DownloadManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import androidx.core.graphics.toColorInt
import androidx.core.net.toUri
import androidx.core.view.isVisible
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.pockit.databinding.ActivityMainBinding
import com.example.pockit.databinding.ItemFileBinding
import com.google.android.material.tabs.TabLayout
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okio.BufferedSink
import okio.source
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel
    
    private var service: PockyService? = null
    private var primaryVolume: Volume? = null
    private var baseUrl: String = ""
    private var backupManager: BackupManager? = null
    
    // --- 文件浏览器状态 ---
    private var currentFilePath = ""
    private var downloadFolderUri: String? = null
    private var pendingDownloadFile: RemoteFile? = null
    private var clipboardPaths = listOf<String>()
    private var clipboardOp = "" // "copy" or "move"
    private var pendingSharedUris = mutableListOf<Uri>()
    private val selectedPaths = mutableSetOf<String>()
    private var isSelectionMode = false
    private var currentRemoteFiles = listOf<RemoteFile>()

    // --- 拖动勾选状态 ---
    private var isDragSelecting = false
    private var dragStartIndex = -1
    private var lastDragIndex = -1
    private var dragSelectionTargetState = true

    private lateinit var galleryAdapter: GalleryAdapter
    
    private var localMedia = mutableListOf<GalleryItem.Local>()
    private var remoteAlbums = mutableListOf<GalleryItem.RemoteAlbum>()
    private var remotePhotos = mutableListOf<GalleryItem.RemotePhoto>()
    private var currentRemoteAlbum: Album? = null

    // --- 播放器状态 ---
    private var isPlayingOnServer = false
    private var currentPlayingTitle = "未在播放"
    private var currentPlayingArtist = "Remote Server Player"
    private var currentPlayingPath: String? = null
    private var currentPlayingCover: ByteArray? = null

    private val barcodeLauncher = registerForActivityResult(ScanContract()) { result ->
        if (result.contents != null) {
            val scanned = result.contents.replace("http://", "").split(":")[0]
            binding.etServerIp.setText(scanned)
            connect(scanned)
        }
    }

    private val uploadLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { uploadFile(it) }
    }

    private val folderPickerLauncher = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri?.let {
            contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            saveDownloadFolder(it.toString())
            pendingDownloadFile?.let { file -> downloadFile(file); pendingDownloadFile = null }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[MainViewModel::class.java]

        initGalleryAdapter()
        loadDownloadSettings()
        setupUI()
        loadSavedConfig()
        checkPermissions()
        handleShareIntent(intent)
    }

    private fun initGalleryAdapter() {
        galleryAdapter = GalleryAdapter(
            getBaseUrl = { baseUrl },
            onSelectionChanged = { updateActions() },
            onAlbumClick = { album ->
                currentRemoteAlbum = album
                fetchRemotePhotos(album)
            },
            onItemClick = { item ->
                when (item) {
                    is GalleryItem.Local -> {
                        startPreview(File(item.media.path).toUri().toString(), item.media.name, item.media.path.isVideoFile())
                    }
                    is GalleryItem.RemotePhoto -> {
                        val name = item.file.name ?: ""
                        startPreview("$baseUrl/api/view?path=${item.file.realPath.urlEncode()}", name, name.isVideoFile())
                    }
                    else -> {}
                }
            },
            onLongClick = { position ->
                val item = galleryAdapter.items.getOrNull(position)
                if (item is GalleryItem.Local) {
                    isDragSelecting = true
                    dragStartIndex = position
                    lastDragIndex = position
                    item.isSelected = !item.isSelected
                    dragSelectionTargetState = item.isSelected
                    galleryAdapter.notifyItemChanged(position)
                    updateActions()
                    true
                } else false
            }
        )
    }

    private fun startPreview(url: String, name: String, isVideo: Boolean) {
        val intent = Intent(this, PreviewActivity::class.java).apply {
            putExtra("url", url)
            putExtra("name", name)
            putExtra("isVideo", isVideo)
        }
        startActivity(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShareIntent(intent)
    }

    private fun handleShareIntent(intent: Intent?) {
        if (intent == null) return
        val action = intent.action
        val type = intent.type
        if ((Intent.ACTION_SEND == action || Intent.ACTION_SEND_MULTIPLE == action) && type != null) {
            pendingSharedUris.clear()
            if (Intent.ACTION_SEND == action) {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)?.let { pendingSharedUris.add(it) }
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.let { pendingSharedUris.addAll(it) }
            }

            if (pendingSharedUris.isNotEmpty()) {
                binding.bottomNav.selectedItemId = R.id.nav_files
                Toast.makeText(this, "已准备好上传 ${pendingSharedUris.size} 个项目，请选择云端目录后点击“粘贴”", Toast.LENGTH_LONG).show()
                showFileBrowser(refreshFiles = false)
            }
        }
    }

    private fun loadDownloadSettings() {
        val prefs = getSharedPreferences("pockit_prefs", MODE_PRIVATE)
        downloadFolderUri = prefs.getString("download_folder_uri", null)
    }

    private fun saveDownloadFolder(uri: String) {
        downloadFolderUri = uri
        getSharedPreferences("pockit_prefs", MODE_PRIVATE).edit { putString("download_folder_uri", uri) }
        if (binding.bottomNav.selectedItemId == R.id.nav_remote) showRemoteControl()
    }

    private fun setupUI() {
        binding.rvGallery.apply {
            layoutManager = GridLayoutManager(this@MainActivity, 3)
            adapter = galleryAdapter
            addOnItemTouchListener(object : RecyclerView.OnItemTouchListener {
                override fun onInterceptTouchEvent(rv: RecyclerView, e: MotionEvent): Boolean {
                    if (isDragSelecting) {
                        if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) {
                            isDragSelecting = false
                            return true
                        }
                        if (e.action == MotionEvent.ACTION_MOVE) {
                            handleDragSelection(rv, e)
                            return true
                        }
                    }
                    return false
                }
                override fun onTouchEvent(rv: RecyclerView, e: MotionEvent) {
                    if (isDragSelecting) {
                        if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) {
                            isDragSelecting = false
                        } else if (e.action == MotionEvent.ACTION_MOVE) {
                            handleDragSelection(rv, e)
                        }
                    }
                }
                override fun onRequestDisallowInterceptTouchEvent(disallowIntercept: Boolean) {}
            })
        }

        binding.btnScan.setOnClickListener { barcodeLauncher.launch(ScanOptions().setPrompt("扫码连接")) }
        binding.btnConnect.setOnClickListener { if (service == null) connect(binding.etServerIp.text.toString().trim()) else disconnect() }
        binding.fabSyncAll.setOnClickListener { performFullBackup() }

        binding.layoutProgress.btnPause.setOnClickListener {
            backupManager?.let {
                it.isPaused = !it.isPaused
                binding.layoutProgress.btnPause.text = if (it.isPaused) "继续" else "暂停"
            }
        }

        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                if (tab?.position == 1 && remoteAlbums.isEmpty() && service != null) fetchRemoteAlbums()
                binding.llHideBackedUpBar.isVisible = tab?.position == 0
                refreshDisplay()
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })

        binding.cbHideBackedUp.setOnCheckedChangeListener { _, _ -> refreshDisplay() }
        binding.tvCancelSelection.setOnClickListener { localMedia.forEach { it.isSelected = false }; refreshDisplay(); updateActions() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (isSelectionMode) { exitSelectionMode(); return }
                if (binding.llGalleryContainer.isVisible) {
                    if (binding.tabLayout.selectedTabPosition == 1 && currentRemoteAlbum != null) {
                        currentRemoteAlbum = null
                        refreshDisplay()
                    } else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                } else if (binding.bottomNav.selectedItemId == R.id.nav_files) {
                    if (currentFilePath.isNotEmpty() && currentFilePath != primaryVolume?.path) {
                        currentFilePath = currentFilePath.substringBeforeLast("/", primaryVolume?.path ?: "")
                        showFileBrowser()
                    } else binding.bottomNav.selectedItemId = R.id.nav_gallery
                } else binding.bottomNav.selectedItemId = R.id.nav_gallery
            }
        })

        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_gallery -> {
                    binding.llGalleryContainer.isVisible = true
                    binding.secondaryContentContainer.isVisible = false
                    updateActions(); true
                }
                R.id.nav_files -> { showFileBrowser(); true }
                R.id.nav_remote -> { showRemoteControl(); true }
                else -> false
            }
        }

        binding.btnCloseSelection.setOnClickListener { exitSelectionMode() }
        binding.btnSelectAll.setOnClickListener { performSelectAll() }
        binding.actionCopy.setOnClickListener { performClipboardOp("copy") }
        binding.actionCut.setOnClickListener { performClipboardOp("move") }
        binding.actionZip.setOnClickListener { performZip() }
        binding.actionDelete.setOnClickListener { confirmDeleteBatch() }
    }

    private fun handleDragSelection(rv: RecyclerView, e: MotionEvent) {
        val view = rv.findChildViewUnder(e.x, e.y)
        if (view != null) {
            val position = rv.getChildAdapterPosition(view)
            if (position != RecyclerView.NO_POSITION && position != lastDragIndex) {
                val start = min(dragStartIndex, position)
                val end = max(dragStartIndex, position)
                for (i in start..end) {
                    val item = galleryAdapter.items.getOrNull(i)
                    if (item is GalleryItem.Local && item.isSelected != dragSelectionTargetState) {
                        item.isSelected = dragSelectionTargetState
                        galleryAdapter.notifyItemChanged(i)
                    }
                }
                lastDragIndex = position
                updateActions()
            }
        }
    }

    private fun performFullBackup() {
        val manager = backupManager ?: run { Toast.makeText(this, "请先连接服务器", Toast.LENGTH_SHORT).show(); return }
        val selectedItems = localMedia.filter { it.isSelected }
        val isSelectionMode = selectedItems.isNotEmpty()
        val itemsToBackup = if (isSelectionMode) selectedItems.map { it.media } else localMedia.map { it.media }

        if (itemsToBackup.isEmpty()) { Toast.makeText(this, "没有可备份的项目", Toast.LENGTH_SHORT).show(); return }

        lifecycleScope.launch {
            try {
                showProgress(true, "准备清单...", "")
                binding.layoutProgress.btnPause.isVisible = true
                binding.layoutProgress.btnPause.text = "暂停"
                binding.layoutProgress.pbBackup.isIndeterminate = true

                val actualCount = manager.prepareManifest(itemsToBackup)
                if (actualCount == 0) {
                    showProgress(false)
                    Toast.makeText(this@MainActivity, "所选项目已全部备份", Toast.LENGTH_SHORT).show()
                    if (isSelectionMode) { localMedia.forEach { it.isSelected = false }; refreshDisplay() }
                    return@launch
                }

                binding.layoutProgress.pbBackup.isIndeterminate = false
                manager.executeBackup(
                    onFileStarted = { index, total, name ->
                        binding.layoutProgress.tvBackupStatus.text = getString(R.string.backup_progress, index, total)
                        binding.layoutProgress.tvBackupDetail.text = name
                    },
                    onByteProgress = { uploaded, totalSize ->
                        binding.layoutProgress.pbBackup.progress = if (totalSize > 0) (uploaded * 100 / totalSize).toInt() else 0
                    }
                )
                showProgress(false)
                Toast.makeText(this@MainActivity, "备份任务处理完毕", Toast.LENGTH_SHORT).show()
                if (isSelectionMode) localMedia.forEach { it.isSelected = false }
                refreshDisplay()
            } catch (e: Exception) {
                showProgress(false)
                if (e !is CancellationException) Toast.makeText(this@MainActivity, "备份中断: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showProgress(show: Boolean, status: String = "", detail: String = "") {
        binding.layoutProgress.cvProgress.isVisible = show
        binding.layoutProgress.tvBackupStatus.text = status
        binding.layoutProgress.tvBackupDetail.text = detail
    }

    private fun showFileBrowser(refreshFiles: Boolean = true) {
        binding.llGalleryContainer.isVisible = false
        binding.secondaryContentContainer.isVisible = true
        binding.fabSyncAll.hide()

        if (binding.secondaryContentContainer.findViewById<View>(R.id.rvFiles) == null) {
            binding.secondaryContentContainer.removeAllViews()
            LayoutInflater.from(this).inflate(R.layout.layout_file_browser, binding.secondaryContentContainer, true)
        }

        val container = binding.secondaryContentContainer
        val breadcrumbContainer = container.findViewById<LinearLayout>(R.id.breadcrumbContainer)
        val rvFiles = container.findViewById<RecyclerView>(R.id.rvFiles)
        val btnPaste = container.findViewById<Button>(R.id.btnPaste)
        val btnBack = container.findViewById<View>(R.id.btnBackParent)
        val btnNewFolder = container.findViewById<View>(R.id.btnNewFolder)
        val fabUpload = container.findViewById<View>(R.id.fabUpload)

        setupBreadcrumbs(breadcrumbContainer)
        btnPaste.isVisible = (clipboardPaths.isNotEmpty() || pendingSharedUris.isNotEmpty()) && !isSelectionMode
        btnPaste.setOnClickListener { performPaste() }
        btnBack.setOnClickListener {
            if (currentFilePath.isNotEmpty() && currentFilePath != primaryVolume?.path) {
                currentFilePath = currentFilePath.substringBeforeLast("/", primaryVolume?.path ?: "")
                showFileBrowser()
            }
        }
        btnNewFolder.setOnClickListener { showNewFolderDialog() }
        fabUpload.setOnClickListener { uploadLauncher.launch("*/*") }

        if (rvFiles.layoutManager == null) rvFiles.layoutManager = LinearLayoutManager(this)

        if (refreshFiles) {
            lifecycleScope.launch {
                try {
                    val files = service?.getFiles(currentFilePath.ifEmpty { null }) ?: emptyList()
                    currentRemoteFiles = files
                    if (currentFilePath.isEmpty() && files.isNotEmpty()) {
                        currentFilePath = files.first().realPath.substringBeforeLast("/")
                        setupBreadcrumbs(breadcrumbContainer)
                    }
                    rvFiles.adapter = FileAdapter(files, isSelectionMode, selectedPaths, baseUrl, { file ->
                        if (isSelectionMode) toggleSelection(file.realPath)
                        else if (file.isDir) { currentFilePath = file.realPath; showFileBrowser() }
                        else handleFileClick(file)
                    }, { file, _ -> if (!isSelectionMode) enterSelectionMode(file.realPath) }, { file, anchor -> showFileMenu(file, anchor) })
                } catch (_: Exception) { Toast.makeText(this@MainActivity, "获取失败", Toast.LENGTH_SHORT).show() }
            }
        } else (rvFiles.adapter as? FileAdapter)?.let { it.isSelectionMode = this.isSelectionMode; it.notifyItemRangeChanged(0, it.itemCount) }
    }

    private fun setupBreadcrumbs(container: LinearLayout) {
        container.removeAllViews()
        val rootPath = primaryVolume?.path ?: ""
        val relativePath = if (currentFilePath.startsWith(rootPath)) currentFilePath.substring(rootPath.length).trimStart('/') else ""
        
        val addCrumb = { name: String, path: String ->
            container.addView(TextView(this).apply {
                text = name
                setTextColor(if (path == currentFilePath) ContextCompat.getColor(context, R.color.purple_500) else Color.BLACK)
                setPadding(24, 16, 24, 16)
                textSize = 14f
                setOnClickListener { if (path != currentFilePath) { currentFilePath = path; showFileBrowser() } }
            })
        }
        addCrumb(primaryVolume?.name ?: "根目录", rootPath)
        if (relativePath.isNotEmpty()) {
            val parts = relativePath.split("/")
            var accumulatedPath = rootPath
            parts.forEach { part ->
                container.addView(TextView(this).apply { text = "›"; setTextColor(Color.GRAY); textSize = 14f })
                accumulatedPath += "/$part"
                addCrumb(part, accumulatedPath)
            }
        }
        container.post { (container.parent as? HorizontalScrollView)?.fullScroll(View.FOCUS_RIGHT) }
    }

    private fun showNewFolderDialog() {
        val et = EditText(this).apply { hint = "文件夹名称" }
        AlertDialog.Builder(this).setTitle("新建文件夹").setView(et).setPositiveButton("创建") { _, _ ->
            val name = et.text.toString().trim()
            if (name.isNotEmpty()) lifecycleScope.launch { try { service?.makeDirectory(currentFilePath, name); showFileBrowser() } catch (_: Exception) { Toast.makeText(this@MainActivity, "创建失败", Toast.LENGTH_SHORT).show() } }
        }.setNegativeButton("取消", null).show()
    }

    private fun uploadFile(uri: Uri) {
        lifecycleScope.launch {
            try {
                val cursor = contentResolver.query(uri, null, null, null, null)
                var fileName = "upload_file"; var fileSize = -1L
                cursor?.use { if (it.moveToFirst()) { fileName = it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)); fileSize = it.getLong(it.getColumnIndexOrThrow(OpenableColumns.SIZE)) } }
                
                showProgress(true, "正在上传: $fileName", "")
                binding.layoutProgress.btnPause.isVisible = false
                binding.layoutProgress.pbBackup.isIndeterminate = true

                val requestFile = object : RequestBody() {
                    override fun contentType() = "application/octet-stream".toMediaTypeOrNull()
                    override fun contentLength() = fileSize
                    override fun writeTo(sink: BufferedSink) { contentResolver.openInputStream(uri)?.use { sink.writeAll(it.source()) } }
                }
                service?.uploadFile(currentFilePath, 0, MultipartBody.Part.createFormData("file", fileName, requestFile))
                showProgress(false)
                Toast.makeText(this@MainActivity, "上传成功", Toast.LENGTH_SHORT).show(); showFileBrowser()
            } catch (e: Exception) { showProgress(false); Toast.makeText(this@MainActivity, "上传失败: ${e.message}", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun downloadFile(file: RemoteFile) {
        val authorizedDir = downloadFolderUri?.let {
            val pickedDir = DocumentFile.fromTreeUri(this, it.toUri())
            if (pickedDir?.exists() == true && pickedDir.canWrite()) pickedDir else null
        }
        if (authorizedDir != null) performManualDownload(file, authorizedDir) else performSystemDownload(file)
    }

    private fun performManualDownload(file: RemoteFile, destDir: DocumentFile) {
        val fileName = file.name ?: "downloaded_file"
        showProgress(true, "正在下载: $fileName", "")
        binding.layoutProgress.btnPause.isVisible = false
        binding.layoutProgress.pbBackup.isIndeterminate = true
        lifecycleScope.launch {
            try {
                val response = withContext(Dispatchers.IO) { service?.downloadFile(file.realPath) }
                if (response?.isSuccessful == true) {
                    withContext(Dispatchers.IO) {
                        val newFile = destDir.createFile("*/*", fileName) ?: throw Exception("无法在目标目录创建文件")
                        contentResolver.openOutputStream(newFile.uri)?.use { output -> response.body()?.byteStream()?.use { it.copyTo(output) } }
                    }
                    showProgress(false)
                    Toast.makeText(this@MainActivity, "下载完成", Toast.LENGTH_SHORT).show()
                } else throw Exception("服务器错误: ${response?.code()}")
            } catch (e: Exception) { showProgress(false); Toast.makeText(this@MainActivity, "下载失败: ${e.localizedMessage}", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun performSystemDownload(file: RemoteFile) {
        val fileName = file.name ?: "downloaded_file"
        try {
            val request = DownloadManager.Request("$baseUrl/api/download?path=${file.realPath.urlEncode()}".toUri())
                .setTitle("口袋云下载").setDescription(fileName)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "口袋云/$fileName")
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
            Toast.makeText(this, "已加入系统下载队列", Toast.LENGTH_LONG).show()
        } catch (_: Exception) { Toast.makeText(this, "下载失败", Toast.LENGTH_SHORT).show() }
    }

    private fun enterSelectionMode(path: String) {
        isSelectionMode = true; selectedPaths.clear(); selectedPaths.add(path)
        binding.llConnectBar.isVisible = false; binding.llSelectionBar.isVisible = true
        binding.llFileActionsBar.isVisible = true; updateSelectionCount(); showFileBrowser(refreshFiles = false)
    }

    private fun exitSelectionMode() {
        isSelectionMode = false; selectedPaths.clear()
        binding.llConnectBar.isVisible = true; binding.llSelectionBar.isVisible = false
        binding.llFileActionsBar.isVisible = false; showFileBrowser(refreshFiles = false)
    }

    private fun toggleSelection(path: String) {
        if (selectedPaths.contains(path)) selectedPaths.remove(path) else selectedPaths.add(path)
        if (selectedPaths.isEmpty()) exitSelectionMode() else { updateSelectionCount(); showFileBrowser(refreshFiles = false) }
    }

    private fun updateSelectionCount() { binding.tvSelectionCount.text = getString(R.string.selection_count, selectedPaths.size) }
    private fun performSelectAll() { currentRemoteFiles.forEach { selectedPaths.add(it.realPath) }; updateSelectionCount(); showFileBrowser(refreshFiles = false) }
    private fun performClipboardOp(op: String) { clipboardPaths = selectedPaths.toList(); clipboardOp = op; Toast.makeText(this, "已加入剪贴板", Toast.LENGTH_SHORT).show(); exitSelectionMode() }

    private fun performPaste() {
        if (pendingSharedUris.isNotEmpty()) { uploadSharedFiles(); return }
        showProgress(true, if (clipboardOp == "copy") "正在复制..." else "正在移动...", "")
        binding.layoutProgress.pbBackup.isIndeterminate = true
        lifecycleScope.launch {
            try {
                if (clipboardOp == "copy") service?.copyFiles(clipboardPaths, currentFilePath) else service?.moveFiles(clipboardPaths, currentFilePath)
                clipboardPaths = emptyList(); showFileBrowser(); showProgress(false)
            } catch (_: Exception) { showProgress(false); Toast.makeText(this@MainActivity, "操作失败", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun uploadSharedFiles() {
        if (service == null) { Toast.makeText(this, "未连接服务器", Toast.LENGTH_SHORT).show(); return }
        lifecycleScope.launch {
            try {
                showProgress(true, "正在准备上传...", "")
                binding.layoutProgress.pbBackup.isIndeterminate = false
                val total = pendingSharedUris.size
                pendingSharedUris.forEachIndexed { index, uri ->
                    val cursor = contentResolver.query(uri, null, null, null, null)
                    var fileName = "shared_${System.currentTimeMillis()}"; var fileSize = -1L
                    cursor?.use { if (it.moveToFirst()) { fileName = it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)); fileSize = it.getLong(it.getColumnIndexOrThrow(OpenableColumns.SIZE)) } }
                    binding.layoutProgress.tvBackupStatus.text = getString(R.string.upload_progress, index + 1, total)
                    binding.layoutProgress.tvBackupDetail.text = fileName
                    binding.layoutProgress.pbBackup.progress = ((index + 1) * 100 / total)
                    val requestFile = object : RequestBody() {
                        override fun contentType() = "application/octet-stream".toMediaTypeOrNull()
                        override fun contentLength() = fileSize
                        override fun writeTo(sink: BufferedSink) { contentResolver.openInputStream(uri)?.use { sink.writeAll(it.source()) } }
                    }
                    service?.uploadFile(currentFilePath, 0, MultipartBody.Part.createFormData("file", fileName, requestFile))
                }
                showProgress(false); Toast.makeText(this@MainActivity, "上传成功", Toast.LENGTH_SHORT).show(); pendingSharedUris.clear(); showFileBrowser()
            } catch (e: Exception) { showProgress(false); Toast.makeText(this@MainActivity, "上传失败: ${e.message}", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun performZip() {
        showProgress(true, "正在压缩...", ""); binding.layoutProgress.pbBackup.isIndeterminate = true
        lifecycleScope.launch { try { service?.zipFiles(selectedPaths.toList(), currentFilePath); exitSelectionMode(); showProgress(false); showFileBrowser() } catch (_: Exception) { showProgress(false); Toast.makeText(this@MainActivity, "压缩失败", Toast.LENGTH_SHORT).show() } }
    }

    private fun confirmDeleteBatch() {
        AlertDialog.Builder(this).setMessage("确认删除选中的 ${selectedPaths.size} 项？").setPositiveButton("删除") { _, _ ->
            showProgress(true, "正在删除...", ""); binding.layoutProgress.pbBackup.isIndeterminate = true
            lifecycleScope.launch { try { selectedPaths.forEach { service?.deleteFile(it) }; exitSelectionMode(); showProgress(false); showFileBrowser() } catch (_: Exception) { showProgress(false); Toast.makeText(this@MainActivity, "删除中断", Toast.LENGTH_SHORT).show() } }
        }.setNegativeButton("取消", null).show()
    }

    private fun showFileMenu(file: RemoteFile, anchor: View) {
        PopupMenu(this, anchor).apply {
            menu.add("下载").setOnMenuItemClickListener { downloadFile(file); true }
            menu.add("重命名").setOnMenuItemClickListener { showRenameDialog(file); true }
            menu.add("删除").setOnMenuItemClickListener { confirmDelete(file); true }
            if (file.name?.isZipFile() == true) menu.add("解压到此处").setOnMenuItemClickListener { unzipFile(file); true }
            show()
        }
    }

    private fun showRenameDialog(file: RemoteFile) {
        val et = EditText(this).apply { setText(file.name) }
        AlertDialog.Builder(this).setTitle("重命名").setView(et).setPositiveButton("确定") { _, _ ->
            lifecycleScope.launch { try { service?.renameFile(file.realPath, et.text.toString()); showFileBrowser() } catch(_: Exception){} }
        }.setNegativeButton("取消", null).show()
    }

    private fun confirmDelete(file: RemoteFile) {
        AlertDialog.Builder(this).setMessage("确定删除 ${file.name}？").setPositiveButton("删除") { _, _ ->
            lifecycleScope.launch { try { service?.deleteFile(file.realPath); showFileBrowser() } catch(_: Exception){} }
        }.setNegativeButton("取消", null).show()
    }

    private fun unzipFile(file: RemoteFile) {
        showProgress(true, "正在解压: ${file.name}", ""); binding.layoutProgress.pbBackup.isIndeterminate = true
        lifecycleScope.launch { try { service?.unzipFile(file.realPath); showProgress(false); showFileBrowser() } catch (_: Exception) { showProgress(false); Toast.makeText(this@MainActivity, "解压失败", Toast.LENGTH_SHORT).show() } }
    }

    private fun handleFileClick(file: RemoteFile) {
        val name = file.name ?: ""
        if (name.isAudioFile()) showRemotePlayDialog(file)
        else if (name.isZipFile()) unzipFile(file)
        else if (name.isImageFile() || name.isVideoFile()) {
            startPreview("$baseUrl/api/view?path=${file.realPath.urlEncode()}", name, name.isVideoFile())
        } else Toast.makeText(this, "正在预览: ${file.name}", Toast.LENGTH_SHORT).show()
    }

    private fun showRemotePlayDialog(file: RemoteFile) {
        AlertDialog.Builder(this).setMessage("是否在服务器播放: ${file.name}？").setPositiveButton("播放") { _, _ ->
            lifecycleScope.launch { 
                try {
                    service?.playOnServer(file.realPath)
                    isPlayingOnServer = true; currentPlayingTitle = file.name ?: "正在播放"; currentPlayingPath = file.realPath
                    fetchRemoteMetadata(file.realPath)
                    if (binding.bottomNav.selectedItemId == R.id.nav_remote) refreshPlayerUI()
                } catch(_: Exception){}
            }
        }.show()
    }

    private fun fetchRemoteMetadata(path: String) {
        val fileUrl = "$baseUrl/api/view?path=${path.urlEncode()}"
        lifecycleScope.launch(Dispatchers.IO) {
            val retriever = android.media.MediaMetadataRetriever()
            try {
                retriever.setDataSource(fileUrl, HashMap())
                val artist = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ARTIST)
                val title = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_TITLE)
                val cover = retriever.embeddedPicture
                withContext(Dispatchers.Main) {
                    if (!title.isNullOrEmpty()) currentPlayingTitle = title
                    if (!artist.isNullOrEmpty()) currentPlayingArtist = artist
                    currentPlayingCover = cover
                    if (binding.bottomNav.selectedItemId == R.id.nav_remote) refreshPlayerUI()
                }
            } catch (_: Exception) {} finally { retriever.release() }
        }
    }

    class FileAdapter(
        private val files: List<RemoteFile>, 
        var isSelectionMode: Boolean,
        private val selectedPaths: Set<String>,
        private val baseUrl: String,
        private val onClick: (RemoteFile) -> Unit, 
        private val onLongClick: (RemoteFile, View) -> Unit,
        private val onMoreClick: (RemoteFile, View) -> Unit
    ) : RecyclerView.Adapter<FileAdapter.VH>() {
        class VH(val b: ItemFileBinding) : RecyclerView.ViewHolder(b.root)
        override fun onCreateViewHolder(p: ViewGroup, t: Int) = VH(ItemFileBinding.inflate(LayoutInflater.from(p.context), p, false))
        override fun onBindViewHolder(h: VH, p: Int) {
            val f = files[p]; val name = f.name ?: "未知"
            h.b.apply {
                tvFileName.text = name
                tvFileDetails.text = if (f.isDir) "文件夹" else "${f.size.formatSize()} • ${if (f.modificationTime > 0) SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(f.modificationTime)) else ""}"
                cbSelect.isVisible = isSelectionMode
                cbSelect.isChecked = selectedPaths.contains(f.realPath)
                rootCard.isChecked = isSelectionMode && selectedPaths.contains(f.realPath)
                if (name.isImageFile()) {
                    ivFileIcon.load("$baseUrl/api/thumbnail?path=${f.realPath.urlEncode()}&size=100") { placeholder(R.drawable.ic_file_image); error(R.drawable.ic_file_image) }
                    ivFileIcon.clearColorFilter()
                } else {
                    val info = getFileIconInfo(f)
                    ivFileIcon.setImageResource(info.first); ivFileIcon.setColorFilter(info.second.toColorInt())
                }
                rootCard.setOnClickListener { onClick(f) }; rootCard.setOnLongClickListener { onLongClick(f, it); true }; btnMore.setOnClickListener { onMoreClick(f, it) }
            }
        }
        override fun getItemCount() = files.size
        private fun getFileIconInfo(f: RemoteFile): Pair<Int, String> {
            val name = f.name?.lowercase() ?: ""
            return when {
                f.isDir -> R.drawable.ic_folder to "#FFCA28"
                name.isZipFile() -> R.drawable.ic_file_generic to "#9C27B0"
                name.isAudioFile() -> R.drawable.ic_file_audio to "#E91E63"
                name.isVideoFile() -> R.drawable.ic_file_video to "#FF5722"
                name.endsWith(".pdf") -> R.drawable.ic_file_generic to "#F44336"
                else -> R.drawable.ic_file_generic to "#2196F3"
            }
        }
    }

    private fun refreshPlayerUI() {
        val v = binding.secondaryContentContainer
        val tvTitle = v.findViewById<TextView>(R.id.tvNowPlayingTitle) ?: return
        val tvArtist = v.findViewById<TextView>(R.id.tvNowPlayingArtist)
        val ivCover = v.findViewById<ImageView>(R.id.ivNowPlaying)
        val btnToggle = v.findViewById<com.google.android.material.floatingactionbutton.FloatingActionButton>(R.id.btnToggle)

        tvTitle.text = if (isPlayingOnServer) currentPlayingTitle else "未在播放"
        tvArtist?.text = if (isPlayingOnServer) currentPlayingArtist else "Remote Server Player"
        btnToggle.setImageResource(if (isPlayingOnServer) R.drawable.ic_pause else R.drawable.ic_play)
        
        if (isPlayingOnServer && currentPlayingPath != null) {
            ivCover.scaleType = ImageView.ScaleType.CENTER_CROP; ivCover.setPadding(0, 0, 0, 0); ivCover.clearColorFilter()
            if (currentPlayingCover != null) ivCover.load(currentPlayingCover) { placeholder(R.drawable.ic_file_audio); error(R.drawable.ic_file_audio) }
            else ivCover.load("$baseUrl/api/thumbnail?path=${currentPlayingPath!!.urlEncode()}&size=100") { placeholder(R.drawable.ic_file_audio); error(R.drawable.ic_file_audio) }
        } else {
            ivCover.scaleType = ImageView.ScaleType.CENTER_INSIDE; val p = (12 * resources.displayMetrics.density).toInt(); ivCover.setPadding(p, p, p, p)
            ivCover.setImageResource(R.drawable.ic_file_audio)
            val typedValue = android.util.TypedValue(); theme.resolveAttribute(com.google.android.material.R.attr.colorPrimary, typedValue, true); ivCover.setColorFilter(typedValue.data)
        }
    }

    private fun showRemoteControl() {
        binding.llGalleryContainer.isVisible = false; binding.secondaryContentContainer.isVisible = true
        binding.secondaryContentContainer.removeAllViews(); binding.fabSyncAll.hide()
        val v = LayoutInflater.from(this).inflate(R.layout.layout_remote_control, binding.secondaryContentContainer, true)
        val cvStorage = v.findViewById<View>(R.id.cvServerStorage); val tvVolName = v.findViewById<TextView>(R.id.tvVolumeName)
        val tvRatio = v.findViewById<TextView>(R.id.tvStorageRatio); val pbStorage = v.findViewById<com.google.android.material.progressindicator.LinearProgressIndicator>(R.id.pbStorage)
        v.findViewById<TextView>(R.id.tvLocalCount).text = getString(R.string.item_count, localMedia.size)
        v.findViewById<TextView>(R.id.tvRemoteCount).text = backupManager?.let { getString(R.string.item_count, it.getTotalRemoteCount()) } ?: "未连接"
        v.findViewById<TextView>(R.id.tvDownloadPath).text = if (downloadFolderUri == null) "Downloads/口袋云" else "已授权自定义目录"
        v.findViewById<View>(R.id.btnChangeDownloadPath).setOnClickListener { folderPickerLauncher.launch(null) }
        v.findViewById<com.google.android.material.floatingactionbutton.FloatingActionButton>(R.id.btnToggle).setOnClickListener { sendPlayerControl("toggle") }
        v.findViewById<View>(R.id.btnStop).setOnClickListener { sendPlayerControl("stop") }
        v.findViewById<View>(R.id.btnVolUp).setOnClickListener { sendPlayerControl("vol-up") }
        v.findViewById<View>(R.id.btnVolDown).setOnClickListener { sendPlayerControl("vol-down") }
        refreshPlayerUI()
        lifecycleScope.launch {
            try {
                val vols = service?.getVolumes(); primaryVolume = vols?.find { it.isPrimary } ?: vols?.firstOrNull()
                primaryVolume?.let { vol ->
                    cvStorage.isVisible = true; tvVolName.text = vol.name; tvRatio.text = getString(R.string.storage_ratio, vol.usedSize.formatSizeGB(), vol.totalSize.formatSizeGB())
                    val usage = if (vol.totalSize > 0) (vol.usedSize * 100 / vol.totalSize).toInt() else 0
                    pbStorage.progress = usage
                    pbStorage.setIndicatorColor(when { usage < 70 -> "#4CAF50".toColorInt(); usage < 90 -> "#FFA000".toColorInt(); else -> "#F44336".toColorInt() })
                } ?: run { cvStorage.isVisible = false }
            } catch (_: Exception) { cvStorage.isVisible = false }
        }
    }

    private fun sendPlayerControl(a: String) { 
        lifecycleScope.launch { 
            try { 
                service?.controlPlayer(a)
                if (a == "toggle") { isPlayingOnServer = !isPlayingOnServer; refreshPlayerUI() }
                else if (a == "stop") { isPlayingOnServer = false; currentPlayingTitle = "已停止"; currentPlayingArtist = "Remote Server Player"; currentPlayingCover = null; refreshPlayerUI() }
            } catch (_: Exception) {} 
        } 
    }

    private fun connect(ip: String) {
        baseUrl = if (ip.contains(":")) "http://$ip" else "http://$ip:9000"
        service = PockyClient.createService(baseUrl)
        lifecycleScope.launch {
            try {
                val vols = service?.getVolumes(); primaryVolume = vols?.find { it.isPrimary } ?: vols?.firstOrNull()
                if (primaryVolume != null) {
                    currentFilePath = primaryVolume!!.path
                    getSharedPreferences("pockit_prefs", MODE_PRIVATE).edit { putString("last_server_ip", ip) }
                    backupManager = BackupManager(this@MainActivity, service!!, primaryVolume!!.path)
                    binding.btnConnect.text = "断开"; Toast.makeText(this@MainActivity, "连接成功", Toast.LENGTH_SHORT).show()
                    syncBackupStatus(); fetchRemoteAlbums()
                    refreshCurrentSecondaryTab()
                } else { service = null; Toast.makeText(this@MainActivity, "未能识别存储卷", Toast.LENGTH_SHORT).show() }
            } catch (_: Exception) { service = null; Toast.makeText(this@MainActivity, "连接失败", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun disconnect() {
        service = null; backupManager = null; baseUrl = ""; binding.btnConnect.text = "连接"
        remoteAlbums.clear(); remotePhotos.clear(); currentRemoteAlbum = null
        localMedia.forEach { it.isBackedUp = false }; refreshDisplay(); refreshCurrentSecondaryTab(); Toast.makeText(this, "已断开", Toast.LENGTH_SHORT).show()
    }

    private fun refreshCurrentSecondaryTab() {
        when (binding.bottomNav.selectedItemId) {
            R.id.nav_files -> showFileBrowser()
            R.id.nav_remote -> showRemoteControl()
        }
    }

    private fun syncBackupStatus() {
        val manager = backupManager ?: return
        lifecycleScope.launch {
            try {
                showProgress(true, "同步云端状态...", "")
                manager.syncRemoteState()
                withContext(Dispatchers.IO) { localMedia.forEach { it.isBackedUp = manager.getBackupStatus(File(it.media.path)).first } }
                showProgress(false); refreshDisplay()
                if (binding.bottomNav.selectedItemId == R.id.nav_remote) showRemoteControl()
            } catch (_: Exception) { showProgress(false) }
        }
    }

    private fun fetchRemoteAlbums() { lifecycleScope.launch { try { remoteAlbums = service?.getAlbums()?.map { GalleryItem.RemoteAlbum(it) }?.toMutableList() ?: mutableListOf(); if (binding.tabLayout.selectedTabPosition == 1) refreshDisplay() } catch (_: Exception) {} } }
    private fun fetchRemotePhotos(a: Album) { lifecycleScope.launch { try { remotePhotos = service?.getPhotos(a.realPath)?.map { GalleryItem.RemotePhoto(it) }?.toMutableList() ?: mutableListOf(); refreshDisplay() } catch (_: Exception) {} } }
    
    private fun refreshDisplay() {
        val isLocal = binding.tabLayout.selectedTabPosition == 0
        galleryAdapter.items = if (isLocal) {
            if (binding.cbHideBackedUp.isChecked) localMedia.filter { !it.isBackedUp } else localMedia
        } else (if (currentRemoteAlbum == null) remoteAlbums else remotePhotos)
        updateActions()
    }

    private fun updateActions() {
        val isLocal = binding.tabLayout.selectedTabPosition == 0
        if (service != null && isLocal) {
            val count = localMedia.count { it.isSelected }
            binding.fabSyncAll.text = if (count > 0) "备份 $count 项" else "全部备份"
            binding.tvCancelSelection.isVisible = count > 0
            binding.fabSyncAll.show()
        } else { binding.fabSyncAll.hide(); binding.tvCancelSelection.isVisible = false }
    }

    private fun checkPermissions() {
        val perms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        if (perms.any { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) ActivityCompat.requestPermissions(this, perms, 100) else scanLocal()
    }
    private fun scanLocal() { lifecycleScope.launch { localMedia = MediaScanner(this@MainActivity).scanMedia().map { GalleryItem.Local(it) }.toMutableList(); refreshDisplay() } }
    private fun loadSavedConfig() { binding.etServerIp.setText(getSharedPreferences("pockit_prefs", MODE_PRIVATE).getString("last_server_ip", "192.168.1.100")) }
}
