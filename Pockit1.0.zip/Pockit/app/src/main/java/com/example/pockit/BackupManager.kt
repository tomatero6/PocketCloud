package com.example.pockit

import android.content.Context
import android.os.Build
import android.util.Log
import kotlinx.coroutines.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okio.BufferedSink
import java.io.File
import java.io.RandomAccessFile

class BackupManager(
    private val context: Context,
    private val service: PockyService,
    private val rootPath: String
) {
    private val deviceName = "口袋云-" + Build.MODEL.replace(" ", "_")
    private val backupRoot = "$rootPath/$deviceName".replace("//", "/")
    
    private var backupQueue = mutableListOf<BackupTask>()
    private val createdDirs = mutableSetOf<String>()
    
    // 缓存：远程路径 -> (文件名 -> 文件大小)
    private val remoteCache = mutableMapOf<String, Map<String, Long>>()
    
    @Volatile
    var isPaused = false

    /**
     * 【大检查】刷新远程备份状态
     */
    suspend fun syncRemoteState() = withContext(Dispatchers.IO) {
        try {
            val newCache = mutableMapOf<String, Map<String, Long>>()
            val folders = try {
                service.getFiles(backupRoot).filter { it.isDir }
            } catch (e: Exception) {
                emptyList()
            }

            for (folder in folders) {
                val files = try {
                    service.getFiles(folder.realPath).filter { !it.isDir }
                } catch (e: Exception) {
                    emptyList()
                }
                newCache[folder.realPath] = files.associate { (it.name ?: "") to it.size }
            }
            
            synchronized(remoteCache) {
                remoteCache.clear()
                remoteCache.putAll(newCache)
            }
        } catch (e: Exception) {
            Log.e("Backup", "Sync remote state failed", e)
        }
    }

    /**
     * 获取当前同步到的远程文件总数
     */
    fun getTotalRemoteCount(): Int {
        return synchronized(remoteCache) {
            remoteCache.values.sumOf { it.size }
        }
    }

    /**
     * 检查本地文件是否已备份，并返回当前已备份的大小
     */
    fun getBackupStatus(localFile: File): Pair<Boolean, Long> {
        val parentFolderName = localFile.parentFile?.name ?: "未命名相册"
        val remotePath = "$backupRoot/$parentFolderName".replace("//", "/")
        val fileName = localFile.name
        
        val remoteSize = synchronized(remoteCache) {
            remoteCache[remotePath]?.get(fileName) ?: 0L
        }
        val localSize = localFile.length()
        
        return (remoteSize >= localSize) to remoteSize
    }

    /**
     * 准备待备份清单
     */
    suspend fun prepareManifest(selectedMedia: List<LocalMediaFile>): Int = withContext(Dispatchers.IO) {
        if (remoteCache.isEmpty()) syncRemoteState()

        val tasks = selectedMedia.sortedBy { it.dateModified }.mapNotNull { media ->
            val localFile = File(media.path)
            if (!localFile.exists()) return@mapNotNull null

            val (isDone, offset) = getBackupStatus(localFile)
            if (!isDone) {
                val parentFolderName = localFile.parentFile?.name ?: "未命名相册"
                BackupTask(
                    localFile = localFile,
                    remotePath = "$backupRoot/$parentFolderName".replace("//", "/"),
                    remoteFileName = media.name,
                    uploadedSize = offset
                )
            } else null
        }
        
        backupQueue = tasks.toMutableList()
        backupQueue.size
    }

    /**
     * 执行备份
     */
    suspend fun executeBackup(
        onFileStarted: (Int, Int, String) -> Unit,
        onByteProgress: (Long, Long) -> Unit
    ) = withContext(Dispatchers.IO) {
        val totalToBackup = backupQueue.size
        if (totalToBackup == 0) return@withContext

        backupQueue.forEachIndexed { index, task ->
            ensureActive()
            while (isPaused) {
                delay(500)
                ensureActive()
            }

            withContext(Dispatchers.Main) {
                onFileStarted(index + 1, totalToBackup, task.remoteFileName)
            }

            try {
                if (task.remotePath !in createdDirs) {
                    ensureRemoteDir(task.remotePath)
                    createdDirs.add(task.remotePath)
                }
                
                val offset = task.uploadedSize
                if (offset < task.localFile.length()) {
                    task.status = TaskStatus.UPLOADING
                    performUploadWithProgress(task, offset, onByteProgress)
                }
                
                task.status = TaskStatus.COMPLETED
                updateCacheAfterSuccess(task.remotePath, task.remoteFileName, task.localFile.length())
                
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                task.status = TaskStatus.FAILED
                Log.e("Backup", "文件备份失败: ${task.remoteFileName}", e)
            }
        }
    }

    private fun updateCacheAfterSuccess(remotePath: String, fileName: String, size: Long) {
        synchronized(remoteCache) {
            val folderMap = remoteCache[remotePath]?.toMutableMap() ?: mutableMapOf()
            folderMap[fileName] = size
            remoteCache[remotePath] = folderMap
        }
    }

    private suspend fun ensureRemoteDir(remotePath: String) {
        if (!remotePath.startsWith(rootPath)) return
        val relativePart = remotePath.removePrefix(rootPath).split("/").filter { it.isNotEmpty() }
        var currentParent = rootPath
        for (part in relativePart) {
            try {
                service.makeDirectory(currentParent, part)
            } catch (e: Exception) {}
            currentParent = if (currentParent.endsWith("/")) "$currentParent$part" else "$currentParent/$part"
        }
    }

    private suspend fun performUploadWithProgress(
        task: BackupTask, 
        offset: Long,
        onByteProgress: (Long, Long) -> Unit
    ) {
        val totalSize = task.localFile.length()
        var lastUpdate = 0L
        
        val requestBody = object : okhttp3.RequestBody() {
            override fun contentType() = "application/octet-stream".toMediaTypeOrNull()
            override fun contentLength(): Long = totalSize - offset
            
            override fun writeTo(sink: BufferedSink) {
                RandomAccessFile(task.localFile, "r").use { raf ->
                    raf.seek(offset)
                    val buffer = ByteArray(64 * 1024)
                    var read: Int
                    var currentUploaded = offset
                    
                    while (raf.read(buffer).also { read = it } != -1) {
                        while (isPaused) { Thread.sleep(500) }
                        sink.write(buffer, 0, read)
                        currentUploaded += read
                        
                        val now = System.currentTimeMillis()
                        if (now - lastUpdate > 200) { // 降低刷新频率
                            val current = currentUploaded
                            // 使用非阻塞方式通知 UI
                            onByteProgress(current, totalSize)
                            lastUpdate = now
                        }
                    }
                    onByteProgress(totalSize, totalSize)
                }
            }
        }

        val filePart = MultipartBody.Part.createFormData("file", task.remoteFileName, requestBody)
        val response = service.uploadFile(task.remotePath, offset, filePart)
        if (!response.isSuccessful) throw Exception("上传失败: ${response.code()}")
    }
}
