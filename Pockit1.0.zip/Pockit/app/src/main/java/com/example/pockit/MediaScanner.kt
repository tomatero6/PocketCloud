package com.example.pockit

import android.content.Context
import android.provider.MediaStore
import android.os.Build
import android.net.Uri

data class LocalMediaFile(
    val id: Long,
    val name: String,
    val path: String,
    val size: Long,
    val dateModified: Long,
    val mimeType: String?
)

class MediaScanner(private val context: Context) {
    fun scanMedia(): List<LocalMediaFile> {
        val mediaFiles = mutableListOf<LocalMediaFile>()
        
        // 分别扫描图片和视频，这是获取 10000+ 全量媒体最稳定可靠的方式
        scanUri(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, mediaFiles)
        scanUri(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, mediaFiles)
        
        // 按时间倒序排列
        return mediaFiles.sortedByDescending { it.dateModified }
    }

    private fun scanUri(collectionUri: Uri, outList: MutableList<LocalMediaFile>) {
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.DATA,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_MODIFIED,
            MediaStore.MediaColumns.MIME_TYPE
        )

        context.contentResolver.query(
            collectionUri,
            projection,
            null,
            null,
            "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)

            while (cursor.moveToNext()) {
                val path = cursor.getString(dataCol) ?: continue
                val size = cursor.getLong(sizeCol)
                if (size <= 0) continue
                
                outList.add(
                    LocalMediaFile(
                        id = cursor.getLong(idCol),
                        name = cursor.getString(nameCol) ?: path.substringAfterLast("/"),
                        path = path,
                        size = size,
                        dateModified = cursor.getLong(dateCol),
                        mimeType = cursor.getString(mimeCol)
                    )
                )
            }
        }
    }
}
