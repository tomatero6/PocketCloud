package com.example.pocky

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import io.ktor.http.*
import io.ktor.http.content.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.http.content.*
import io.ktor.server.netty.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.server.plugins.partialcontent.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import io.ktor.utils.io.jvm.javaio.*
import kotlinx.coroutines.*
import kotlinx.serialization.Serializable
import java.io.File
import java.io.RandomAccessFile
import java.net.NetworkInterface

@Serializable
data class UploadResponse(val success: Boolean, val count: Int = 0, val error: String? = null)

class HttpServerService : Service() {

    private var server: EmbeddedServer<NettyApplicationEngine, NettyApplicationEngine.Configuration>? = null
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var repository: MediaRepository? = null
    private var mediaPlayer: MediaPlayer? = null
    private lateinit var audioManager: AudioManager

    companion object {
        @Suppress("DEPRECATION")
        fun isRunning(context: Context): Boolean {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val services = manager.getRunningServices(Int.MAX_VALUE)
            return services.any { it.service.className == HttpServerService::class.java.name }
        }

        fun getIpAddress(): String {
            try {
                val interfaces = NetworkInterface.getNetworkInterfaces()
                while (interfaces.hasMoreElements()) {
                    val iface = interfaces.nextElement()
                    if (iface.isLoopback || !iface.isUp) continue
                    val addresses = iface.inetAddresses
                    while (addresses.hasMoreElements()) {
                        val addr = addresses.nextElement()
                        if (addr is java.net.Inet4Address) return addr.hostAddress ?: "0.0.0.0"
                    }
                }
            } catch (e: Exception) { }
            return "0.0.0.0"
        }
    }

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val notification = createNotification("服务器正在启动...")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(1, notification)
        }
        serviceScope.launch {
            try {
                repository = MediaRepository(this@HttpServerService)
                startServer()
                val ip = getIpAddress()
                updateNotification("口袋云在线: http://$ip:9000")
            } catch (e: Exception) {
                updateNotification("启动失败: ${e.message ?: "未知错误"}")
            }
        }
    }

    private fun startServer() {
        server?.stop(100, 500)
        
        val newServer = embeddedServer(Netty, port = 9000) {
            install(ContentNegotiation) { json() }
            install(PartialContent)
            
            routing {
                get("/") { call.respondText(WebUiProvider.getWebUi(), ContentType.Text.Html) }
                
                get("/api/volumes") { 
                    call.respond(repository?.getStorageVolumes() ?: emptyList()) 
                }

                get("/api/albums") {
                    try {
                        val albums = repository?.getInternalAlbumFolders() ?: emptyList()
                        call.respond(albums)
                    } catch (e: Exception) {
                        call.respond(HttpStatusCode.InternalServerError, mapOf("error" to e.message))
                    }
                }

                get("/api/photos") {
                    try {
                        val path = call.request.queryParameters["path"] ?: ""
                        if (path.isEmpty()) return@get call.respond(HttpStatusCode.BadRequest, "Path required")
                        val photos = repository?.getPhotosInDirectory(path) ?: emptyList()
                        call.respond(photos)
                    } catch (e: Exception) {
                        call.respond(HttpStatusCode.InternalServerError, mapOf("error" to e.message))
                    }
                }

                get("/api/files") {
                    val path = call.request.queryParameters["path"] ?: "/storage/emulated/0"
                    val files = repository?.getFiles(path) ?: emptyList()
                    call.respond(files)
                }

                get("/api/upload/status") {
                    try {
                        val path = call.request.queryParameters["path"] ?: ""
                        val name = call.request.queryParameters["name"] ?: ""
                        val file = File(path, name)
                        if (file.exists() && file.isFile) {
                            val md5 = repository?.calculateMD5(file) ?: ""
                            call.respond(mapOf("size" to file.length(), "md5" to md5))
                        } else {
                            call.respond(mapOf("size" to 0L, "md5" to ""))
                        }
                    } catch (e: Exception) {
                        call.respond(HttpStatusCode.InternalServerError, mapOf("error" to e.message))
                    }
                }

                get("/api/view") {
                    val path = call.request.queryParameters["path"] ?: return@get call.respond(HttpStatusCode.BadRequest)
                    val file = File(path)
                    if (file.exists()) {
                        val encodedName = file.name.encodeURLParameter()
                        val extension = file.extension.lowercase()
                        
                        val contentType = when (extension) {
                            "mp3" -> ContentType.Audio.MPEG
                            "m4a" -> ContentType("audio", "mp4")
                            "wav" -> ContentType("audio", "wav")
                            "aac" -> ContentType("audio", "aac")
                            "ogg" -> ContentType.Audio.OGG
                            "flac" -> ContentType("audio", "flac")
                            "mp4" -> ContentType.Video.MP4
                            "mov" -> ContentType.Video.QuickTime
                            "jpg", "jpeg" -> ContentType.Image.JPEG
                            "png" -> ContentType.Image.PNG
                            "gif" -> ContentType.Image.GIF
                            "webp" -> ContentType("image", "webp")
                            else -> ContentType.defaultForFile(file)
                        }

                        call.response.header(HttpHeaders.ContentDisposition, "inline; filename*=UTF-8''$encodedName")
                        call.respond(LocalFileContent(file = file, contentType = contentType))
                    } else call.respond(HttpStatusCode.NotFound)
                }

                get("/api/thumbnail") {
                    val path = call.request.queryParameters["path"] ?: return@get call.respond(HttpStatusCode.BadRequest)
                    val size = call.request.queryParameters["size"]?.toIntOrNull() ?: 300
                    val thumb = repository?.getThumbnail(path, size)
                    if (thumb != null) {
                        call.respondBytes(thumb, ContentType.Image.JPEG)
                    } else {
                        val file = File(path)
                        if (file.exists()) call.respondFile(file) else call.respond(HttpStatusCode.NotFound)
                    }
                }

                get("/api/download") {
                    val path = call.request.queryParameters["path"] ?: return@get call.respond(HttpStatusCode.BadRequest)
                    val file = File(path)
                    if (file.exists()) {
                        val client = getClientName(call.request)
                        withContext(Dispatchers.Main) { ServerEvents.startTransfer("下载", client, file.name) }
                        try {
                            val encodedName = file.name.encodeURLParameter()
                            call.response.header(HttpHeaders.ContentDisposition, "attachment; filename*=UTF-8''$encodedName")
                            call.respondFile(file)
                        } finally {
                            withContext(NonCancellable + Dispatchers.Main) { 
                                ServerEvents.endTransfer("下载", client, file.name) 
                            }
                        }
                    } else call.respond(HttpStatusCode.NotFound)
                }

                delete("/api/delete") {
                    val path = call.request.queryParameters["path"] ?: return@delete call.respond(HttpStatusCode.BadRequest)
                    val file = File(path)
                    if (file.exists() && file.deleteRecursively()) {
                        withContext(Dispatchers.Main) { ServerEvents.refreshTrigger.value++ }
                        call.respond(mapOf("success" to true))
                    } else call.respond(HttpStatusCode.InternalServerError, "Delete failed")
                }

                post("/api/play-on-server") {
                    val path = call.request.queryParameters["path"] ?: return@post call.respond(HttpStatusCode.BadRequest)
                    withContext(Dispatchers.Main) {
                        playMusicOnDevice(path)
                    }
                    call.respond(mapOf("success" to true))
                }
                
                post("/api/player-control") {
                    val action = call.request.queryParameters["action"] ?: return@post call.respond(HttpStatusCode.BadRequest)
                    withContext(Dispatchers.Main) {
                        when (action) {
                            "toggle" -> {
                                mediaPlayer?.let {
                                    if (it.isPlaying) it.pause() else it.start()
                                    ServerEvents.isPlaying.value = it.isPlaying
                                }
                            }
                            "stop" -> stopMusicOnDevice()
                            "vol-up" -> {
                                audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                            }
                            "vol-down" -> {
                                audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                            }
                        }
                    }
                    call.respond(mapOf("success" to true))
                }

                post("/api/upload") {
                    try {
                        val targetPath = call.request.queryParameters["path"] ?: "/storage/emulated/0"
                        val offset = call.request.queryParameters["offset"]?.toLongOrNull() ?: 0L
                        val multipart = call.receiveMultipart()
                        val client = getClientName(call.request)
                        var count = 0

                        multipart.forEachPart { part ->
                            if (part is PartData.FileItem) {
                                val name = part.originalFileName ?: "upload_${System.currentTimeMillis()}"
                                val file = File(targetPath, name)
                                file.parentFile?.mkdirs()

                                withContext(Dispatchers.Main) { ServerEvents.startTransfer("上传", client, name) }
                                try {
                                    // Ktor 3.0 推荐方式：使用 provider().toInputStream() 替代废弃的 streamProvider()
                                    part.provider().toInputStream().use { input ->
                                        RandomAccessFile(file, "rw").use { raf ->
                                            if (offset == 0L) raf.setLength(0) 
                                            raf.seek(offset)
                                            val buffer = ByteArray(1024 * 1024) 
                                            var bytesRead = input.read(buffer)
                                            while (bytesRead != -1) {
                                                raf.write(buffer, 0, bytesRead)
                                                bytesRead = input.read(buffer)
                                            }
                                        }
                                    }
                                    val ext = file.extension.lowercase()
                                    if (repository?.isImage(ext) == true || repository?.isVideo(ext) == true || repository?.isAudio(ext) == true) {
                                        MediaScannerConnection.scanFile(this@HttpServerService, arrayOf(file.absolutePath), null, null)
                                    }
                                    count++
                                } finally {
                                    withContext(NonCancellable + Dispatchers.Main) {
                                        ServerEvents.endTransfer("上传", client, name)
                                    }
                                }
                            }
                            part.dispose()
                        }
                        
                        withContext(Dispatchers.Main) { ServerEvents.refreshTrigger.value++ }
                        call.respond(UploadResponse(success = true, count = count))
                    } catch (e: Exception) {
                        call.respond(HttpStatusCode.InternalServerError, UploadResponse(success = false, error = e.message))
                    }
                }

                post("/api/mkdir") {
                    try {
                        val parent = call.request.queryParameters["path"] ?: "/storage/emulated/0"
                        val name = call.request.queryParameters["name"] ?: "New Folder"
                        val newDir = File(parent, name)
                        
                        if (newDir.exists()) {
                            call.respond(mapOf("success" to true, "existed" to true))
                        } else if (newDir.mkdirs()) {
                            withContext(Dispatchers.Main) { ServerEvents.refreshTrigger.value++ }
                            call.respond(mapOf("success" to true))
                        } else {
                            call.respond(HttpStatusCode.Forbidden, "Could not create directory")
                        }
                    } catch (e: Exception) {
                        call.respond(HttpStatusCode.InternalServerError, e.message ?: "Error")
                    }
                }

                post("/api/copy") {
                    try {
                        val from = call.request.queryParameters.getAll("from") ?: emptyList()
                        val to = call.request.queryParameters["to"] ?: return@post call.respond(HttpStatusCode.BadRequest)
                        val targetDir = File(to)
                        if (!targetDir.exists()) targetDir.mkdirs()
                        
                        from.forEach { path ->
                            val src = File(path)
                            if (src.exists()) {
                                src.copyRecursively(File(targetDir, src.name), overwrite = true)
                            }
                        }
                        withContext(Dispatchers.Main) { ServerEvents.refreshTrigger.value++ }
                        call.respond(mapOf("success" to true))
                    } catch (e: Exception) {
                        call.respond(HttpStatusCode.InternalServerError, e.message ?: "Error")
                    }
                }

                post("/api/move") {
                    try {
                        val from = call.request.queryParameters.getAll("from") ?: emptyList()
                        val to = call.request.queryParameters["to"] ?: return@post call.respond(HttpStatusCode.BadRequest)
                        val targetDir = File(to)
                        if (!targetDir.exists()) targetDir.mkdirs()
                        
                        from.forEach { path ->
                            val src = File(path)
                            if (src.exists()) {
                                val dest = File(targetDir, src.name)
                                if (src.renameTo(dest)) {
                                    // Success
                                } else {
                                    src.copyRecursively(dest, overwrite = true)
                                    src.deleteRecursively()
                                }
                            }
                        }
                        withContext(Dispatchers.Main) { ServerEvents.refreshTrigger.value++ }
                        call.respond(mapOf("success" to true))
                    } catch (e: Exception) {
                        call.respond(HttpStatusCode.InternalServerError, e.message ?: "Error")
                    }
                }

                post("/api/rename") {
                    try {
                        val path = call.request.queryParameters["path"] ?: return@post call.respond(HttpStatusCode.BadRequest)
                        val newName = call.request.queryParameters["newName"] ?: return@post call.respond(HttpStatusCode.BadRequest)
                        val file = File(path)
                        if (file.exists()) {
                            val dest = File(file.parentFile, newName)
                            if (file.renameTo(dest)) {
                                val ext = dest.extension.lowercase()
                                if (repository?.isImage(ext) == true || repository?.isVideo(ext) == true || repository?.isAudio(ext) == true) {
                                    MediaScannerConnection.scanFile(this@HttpServerService, arrayOf(dest.absolutePath), null, null)
                                }
                                withContext(Dispatchers.Main) { ServerEvents.refreshTrigger.value++ }
                                call.respond(mapOf("success" to true))
                            } else {
                                call.respond(HttpStatusCode.InternalServerError, "Rename failed")
                            }
                        } else {
                            call.respond(HttpStatusCode.NotFound)
                        }
                    } catch (e: Exception) {
                        call.respond(HttpStatusCode.InternalServerError, e.message ?: "Error")
                    }
                }

                post("/api/zip") {
                    try {
                        val from = call.request.queryParameters.getAll("from") ?: emptyList()
                        val toDir = call.request.queryParameters["to"] ?: return@post call.respond(HttpStatusCode.BadRequest)
                        if (from.isEmpty()) return@post call.respond(HttpStatusCode.BadRequest, "No files selected")
                        
                        val firstFile = File(from[0])
                        val zipName = if (from.size == 1) "${firstFile.nameWithoutExtension}.zip" else "archive_${System.currentTimeMillis()}.zip"
                        val zipFile = File(toDir, zipName)
                        
                        val success = repository?.zip(from.map { File(it) }, zipFile) ?: false
                        if (success) {
                            withContext(Dispatchers.Main) { ServerEvents.refreshTrigger.value++ }
                            call.respond(mapOf("success" to true))
                        } else {
                            call.respond(HttpStatusCode.InternalServerError, "Zip failed")
                        }
                    } catch (e: Exception) {
                        call.respond(HttpStatusCode.InternalServerError, e.message ?: "Error")
                    }
                }

                post("/api/unzip") {
                    try {
                        val path = call.request.queryParameters["path"] ?: return@post call.respond(HttpStatusCode.BadRequest)
                        val zipFile = File(path)
                        if (!zipFile.exists() || zipFile.extension.lowercase() != "zip") {
                            return@post call.respond(HttpStatusCode.BadRequest, "Not a zip file")
                        }
                        
                        val targetDir = File(zipFile.parent, zipFile.nameWithoutExtension)
                        val success = repository?.unzip(zipFile, targetDir) ?: false
                        if (success) {
                            withContext(Dispatchers.Main) { ServerEvents.refreshTrigger.value++ }
                            call.respond(mapOf("success" to true))
                        } else {
                            call.respond(HttpStatusCode.InternalServerError, "Unzip failed")
                        }
                    } catch (e: Exception) {
                        call.respond(HttpStatusCode.InternalServerError, e.message ?: "Error")
                    }
                }
            }
        }
        server = newServer
        newServer.start(wait = false) 
    }

    private fun playMusicOnDevice(path: String) {
        try {
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setDataSource(this@HttpServerService, Uri.fromFile(File(path)))
                prepare()
                start()
                setOnCompletionListener {
                    ServerEvents.isPlaying.value = false
                    ServerEvents.currentPlayingPath.value = null
                }
            }
            ServerEvents.currentPlayingPath.value = path
            ServerEvents.isPlaying.value = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun stopMusicOnDevice() {
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
        ServerEvents.currentPlayingPath.value = null
        ServerEvents.isPlaying.value = false
    }

    private fun getClientName(request: ApplicationRequest): String {
        val ua = request.header(HttpHeaders.UserAgent) ?: ""
        return when {
            ua.contains("Windows") -> "Windows 电脑"
            ua.contains("Macintosh") -> "Mac 电脑"
            ua.contains("iPhone") -> "iPhone 手机"
            ua.contains("Android") -> "安卓设备"
            else -> request.local.remoteHost
        }
    }

    private fun createNotification(text: String): Notification {
        val channelId = "pocky_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Pocky Server", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("口袋云助手")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(1, createNotification(text))
    }

    override fun onDestroy() {
        server?.stop(100, 500)
        server = null
        mediaPlayer?.release()
        mediaPlayer = null
        serviceScope.cancel()
        getSystemService(NotificationManager::class.java).cancel(1)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
