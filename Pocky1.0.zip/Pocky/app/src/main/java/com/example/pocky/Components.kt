package com.example.pocky

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import java.text.DecimalFormat

@Composable
fun AlbumFolderItem(folder: AlbumFolder, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable { onClick() }
    ) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(folder.firstImagePath)
                .crossfade(true)
                .build(),
            contentDescription = null,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f),
            contentScale = ContentScale.Crop
        )
        Column(modifier = Modifier.padding(8.dp)) {
            Text(text = folder.name, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(text = stringResource(R.string.photos_count, folder.count), fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable
fun ActionItem(
    icon: ImageVector,
    label: String,
    isDanger: Boolean = false,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isDanger) MaterialTheme.colorScheme.error else LocalContentColor.current,
            modifier = Modifier.size(24.dp)
        )
        Text(
            text = label,
            fontSize = 10.sp,
            color = if (isDanger) MaterialTheme.colorScheme.error else LocalContentColor.current
        )
    }
}

@Composable
fun StorageCapacityCard(volume: StorageVolumeInfo) {
    val df = DecimalFormat("#.##")
    val totalGB = volume.totalSize.toDouble() / (1024 * 1024 * 1024)
    val availGB = volume.availableSize.toDouble() / (1024 * 1024 * 1024)
    val usedGB = totalGB - availGB
    val progress = if (totalGB > 0) (usedGB / totalGB).toFloat() else 0f

    Card(modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(volume.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("${df.format(usedGB)}G / ${df.format(totalGB)}G", fontSize = 14.sp)
            }
            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = if (progress > 0.9f) Color.Red else MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }
    }
}
