package com.example.pocky

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf

data class TransferInfo(
    val id: String,
    val type: String,
    val client: String,
    val fileName: String
)

object ServerEvents {
    var isServerRunning = mutableStateOf(false)
    var lastAction = mutableStateOf("服务器正在运行")
    var refreshTrigger = mutableStateOf(0)
    val activeTransfers = mutableStateListOf<TransferInfo>()
    
    // 用于通知 App 播放音乐的状态
    var currentPlayingPath = mutableStateOf<String?>(null)
    var isPlaying = mutableStateOf(false)

    private val transferRefs = mutableMapOf<String, Int>()

    fun startTransfer(type: String, client: String, fileName: String) {
        val key = "$type:$client:$fileName"
        val current = transferRefs.getOrDefault(key, 0)
        if (current == 0) {
            activeTransfers.add(TransferInfo(key, type, client, fileName))
        }
        transferRefs[key] = current + 1
    }

    fun endTransfer(type: String, client: String, fileName: String) {
        val key = "$type:$client:$fileName"
        val current = transferRefs.getOrDefault(key, 0)
        if (current <= 1) {
            transferRefs.remove(key)
            activeTransfers.removeAll { it.id == key }
        } else {
            transferRefs[key] = current - 1
        }
    }
}
