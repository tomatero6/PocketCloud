package com.example.pocky

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.ThumbnailUtils
import android.os.Build
import android.os.StatFs
import android.os.storage.StorageManager
import android.provider.MediaStore
import android.util.Size
import androidx.compose.runtime.Immutable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import java.io.*
import java.security.MessageDigest
import java.text.Collator
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

@Immutable
@Serializable
data class MediaItem(
    val id: Long,
    val name: String,
    val path: String,
    val isDir: Boolean = false,
    val size: Long = 0,
    val folderName: String = "",
    val isSystem: Boolean = false,
    val md5: String? = null,
    val lastModified: Long = 0
)

@Immutable
@Serializable
data class AlbumFolder(
    val name: String,
    val firstImagePath: String,
    val count: Int,
    val fullPath: String
)

@Immutable
@Serializable
data class StorageVolumeInfo(
    val name: String,
    val path: String,
    val isPrimary: Boolean,
    val totalSize: Long = 0,
    val availableSize: Long = 0,
    val hardwareSizeGB: Int = 0 
)

class MediaRepository(context: Context) {
    // 使用 ApplicationContext 避免内存泄漏
    private val appContext = context.applicationContext

    companion object {
        var cachedFolders = listOf<AlbumFolder>()
        private val collator = Collator.getInstance(Locale.CHINA)
    }

    private val imageExtensions = setOf(
        "jpg", "jpeg", "png", "webp", "gif", "bmp", "ico", "heic", "heif", "avif", "tiff", "tif", "svg",
        "dng", "cr2", "cr3", "nef", "nrw", "arw", "srf", "sr2", "orf", "rw2", "raf", "pef", "x3f", "kdc", "dcr"
    )

    private val videoExtensions = setOf(
        "mp4", "mov", "m4v", "mkv", "webm", "avi", "wmv", "flv", "3gp", "ts"
    )

    private val audioExtensions = setOf(
        "mp3", "wav", "flac", "aac", "m4a", "ogg", "wma", "ape"
    )

    fun isImage(extension: String): Boolean = imageExtensions.contains(extension.lowercase())
    fun isVideo(extension: String): Boolean = videoExtensions.contains(extension.lowercase())
    fun isAudio(extension: String): Boolean = audioExtensions.contains(extension.lowercase())

    suspend fun getThumbnail(path: String, size: Int = 300): ByteArray? = withContext(Dispatchers.IO) {
        try {
            val file = File(path)
            if (!file.exists()) return@withContext null
            val ext = file.extension.lowercase()
            
            val bitmap = when {
                isImage(ext) -> {
                    val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeFile(path, options)
                    options.inSampleSize = calculateInSampleSize(options, size, size)
                    options.inJustDecodeBounds = false
                    BitmapFactory.decodeFile(path, options)
                }
                isVideo(ext) -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ThumbnailUtils.createVideoThumbnail(file, Size(size, size), null)
                    } else {
                        @Suppress("DEPRECATION")
                        ThumbnailUtils.createVideoThumbnail(path, MediaStore.Video.Thumbnails.MINI_KIND)
                    }
                }
                else -> null
            } ?: return@withContext null

            ByteArrayOutputStream().use { stream ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 75, stream)
                bitmap.recycle()
                stream.toByteArray()
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun calculateInSampleSize(options: BitmapFactory.Options, reqWidth: Int, reqHeight: Int): Int {
        val (height: Int, width: Int) = options.outHeight to options.outWidth
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight = height / 2
            val halfWidth = width / 2
            while (halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    private fun getSortCategory(name: String): Int {
        if (name.isEmpty()) return 4
        val c = name[0]
        return when {
            isChinese(c) -> 1
            c.isDigit() -> 2
            (c in 'a'..'z' || c in 'A'..'Z') -> 3
            else -> 4
        }
    }

    private fun isChinese(c: Char): Boolean {
        val code = c.code
        if (code in 0x4E00..0x9FA5) return true
        return Character.UnicodeScript.of(code) == Character.UnicodeScript.HAN
    }

    private fun compareNames(n1: String, n2: String): Int {
        val cat1 = getSortCategory(n1)
        val cat2 = getSortCategory(n2)
        if (cat1 != cat2) return cat1 - cat2
        return if (cat1 == 1) {
            collator.compare(n1, n2)
        } else {
            n1.compareTo(n2, ignoreCase = true)
        }
    }

    suspend fun calculateMD5(file: File): String = withContext(Dispatchers.IO) {
        if (!file.exists() || file.isDirectory) return@withContext ""
        try {
            val digest = MessageDigest.getInstance("MD5")
            FileInputStream(file).use { input ->
                val buffer = ByteArray(128 * 1024)
                var bytesRead: Int
                while (input.read(buffer).also { bytesRead = it } != -1) {
                    digest.update(buffer, 0, bytesRead)
                }
            }
            digest.digest().joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            ""
        }
    }

    fun getStorageVolumes(): List<StorageVolumeInfo> {
        val volumes = mutableListOf<StorageVolumeInfo>()
        val storageManager = appContext.getSystemService(Context.STORAGE_SERVICE) as StorageManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            for (volume in storageManager.storageVolumes) {
                val path = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    volume.directory?.absolutePath
                } else {
                    try {
                        val method = volume.javaClass.getMethod("getPath")
                        method.invoke(volume) as String?
                    } catch (e: Exception) { null }
                }
                if (path != null) {
                    val label = volume.getDescription(appContext)
                    val stat = StatFs(path)
                    volumes.add(StorageVolumeInfo(label ?: "磁盘", path, volume.isPrimary, stat.totalBytes, stat.availableBytes))
                }
            }
        }
        return volumes.distinctBy { it.path }
    }

    suspend fun getInternalAlbumFolders(): List<AlbumFolder> = withContext(Dispatchers.IO) {
        val folderMap = mutableMapOf<String, Triple<String, Int, String>>() // BUCKET_ID -> (latestPath, count, name)
        
        val projection = arrayOf(
            MediaStore.Images.Media.DATA, 
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Images.Media.BUCKET_ID
        )
        try {
            appContext.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                null, null,
                "${MediaStore.Images.Media.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
                val bucketNameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
                val bucketIdCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_ID)
                
                while (cursor.moveToNext()) {
                    val path = cursor.getString(dataCol)
                    val bucketName = cursor.getString(bucketNameCol) ?: "其他"
                    val bucketId = cursor.getString(bucketIdCol)
                    
                    val entry = folderMap[bucketId]
                    if (entry == null) {
                        folderMap[bucketId] = Triple(path, 1, bucketName)
                    } else {
                        folderMap[bucketId] = entry.copy(second = entry.second + 1)
                    }
                }
            }
        } catch (e: Exception) { e.printStackTrace() }
        
        val result = folderMap.values.map { (path, count, name) ->
            AlbumFolder(name, path, count, File(path).parent ?: "")
        }.sortedByDescending { it.count }
        
        cachedFolders = result
        result
    }

    suspend fun scanExternalAlbumFolders(rootPath: String): List<AlbumFolder> = withContext(Dispatchers.IO) {
        val root = File(rootPath)
        val folderMap = mutableMapOf<String, MutableList<File>>()
        fun scan(dir: File, depth: Int) {
            if (depth > 2) return
            val files = dir.listFiles() ?: return
            for (file in files) {
                if (file.isDirectory) {
                    if (!file.name.startsWith(".")) scan(file, depth + 1)
                } else if (isImage(file.extension) || isVideo(file.extension)) {
                    folderMap.getOrPut(dir.absolutePath) { mutableListOf() }.add(file)
                }
            }
        }
        scan(root, 0)
        
        val result = folderMap.map { (path, files) -> 
            val latestFile = files.maxByOrNull { it.lastModified() }
            AlbumFolder(File(path).name, latestFile?.absolutePath ?: "", files.size, path)
        }.sortedByDescending { it.count }
        
        cachedFolders = result
        result
    }

    suspend fun getPhotosInDirectory(dirPath: String): List<MediaItem> = withContext(Dispatchers.IO) {
        val dir = File(dirPath)
        val files = dir.listFiles() ?: return@withContext emptyList()
        files.filter { it.isFile && (isImage(it.extension) || isVideo(it.extension) || isAudio(it.extension)) }
            .map { file ->
                MediaItem(file.absolutePath.hashCode().toLong(), file.name, file.absolutePath, false, file.length(), dir.name, lastModified = file.lastModified())
            }
            .sortedByDescending { it.lastModified }
    }

    suspend fun getFiles(path: String, offset: Int = 0, limit: Int = Int.MAX_VALUE): List<MediaItem> = withContext(Dispatchers.IO) {
        val dir = File(path)
        if (!dir.exists() || !dir.isDirectory) return@withContext emptyList<MediaItem>()
        
        val allFiles = dir.listFiles() ?: return@withContext emptyList<MediaItem>()
        
        val items = allFiles.map { file ->
            val fileName = file.name
            val absolutePath = file.absolutePath
            MediaItem(
                id = absolutePath.hashCode().toLong(),
                name = fileName,
                path = absolutePath,
                isDir = file.isDirectory,
                size = if (file.isDirectory) 0 else file.length(),
                isSystem = isSystemFolder(file, fileName, absolutePath),
                lastModified = file.lastModified()
            )
        }.sortedWith { a, b ->
            if (a.isSystem != b.isSystem) return@sortedWith if (a.isSystem) 1 else -1
            if (a.isDir != b.isDir) return@sortedWith if (a.isDir) -1 else 1
            compareNames(a.name, b.name)
        }

        if (offset >= items.size) return@withContext emptyList<MediaItem>()
        val end = (offset + limit).coerceAtMost(items.size)
        items.subList(offset, end)
    }

    private fun isSystemFolder(file: File, name: String = file.name, path: String = file.absolutePath): Boolean {
        if (name.equals("DCIM", ignoreCase = true)) return false
        return name.startsWith(".") || name.equals("Android", ignoreCase = true) || path.contains("/Android/data")
    }

    suspend fun mkdir(parent: String, name: String): Boolean = withContext(Dispatchers.IO) {
        File(parent, name).mkdirs()
    }

    suspend fun delete(path: String): Boolean = withContext(Dispatchers.IO) {
        File(path).deleteRecursively()
    }

    suspend fun rename(path: String, newName: String): Boolean = withContext(Dispatchers.IO) {
        val file = File(path)
        val dest = File(file.parentFile, newName)
        file.renameTo(dest)
    }

    suspend fun copy(fromPaths: List<String>, toDir: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val targetDir = File(toDir)
            if (!targetDir.exists()) targetDir.mkdirs()
            fromPaths.forEach { path ->
                val src = File(path)
                if (src.exists()) {
                    src.copyRecursively(File(targetDir, src.name), overwrite = true)
                }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun move(fromPaths: List<String>, toDir: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val targetDir = File(toDir)
            if (!targetDir.exists()) targetDir.mkdirs()
            fromPaths.forEach { path ->
                val src = File(path)
                if (src.exists()) {
                    val dest = File(targetDir, src.name)
                    if (!src.renameTo(dest)) {
                        src.copyRecursively(dest, overwrite = true)
                        src.deleteRecursively()
                    }
                }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun zip(files: List<File>, zipFile: File): Boolean = withContext(Dispatchers.IO) {
        try {
            ZipOutputStream(BufferedOutputStream(FileOutputStream(zipFile))).use { zos ->
                files.forEach { file ->
                    addToZip(file, "", zos)
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun addToZip(file: File, parentPath: String, zos: ZipOutputStream) {
        val entryName = if (parentPath.isEmpty()) file.name else "$parentPath/${file.name}"
        if (file.isDirectory) {
            val children = file.listFiles()
            if (children.isNullOrEmpty()) {
                zos.putNextEntry(ZipEntry("$entryName/"))
                zos.closeEntry()
            } else {
                children.forEach { child ->
                    addToZip(child, entryName, zos)
                }
            }
        } else {
            BufferedInputStream(FileInputStream(file)).use { fis ->
                zos.putNextEntry(ZipEntry(entryName))
                fis.copyTo(zos, bufferSize = 64 * 1024)
                zos.closeEntry()
            }
        }
    }

    suspend fun unzip(zipFile: File, targetDir: File): Boolean = withContext(Dispatchers.IO) {
        try {
            if (!targetDir.exists()) targetDir.mkdirs()
            ZipFile(zipFile).use { zip ->
                zip.entries().asSequence().forEach { entry ->
                    val resolvedFile = File(targetDir, entry.name)
                    if (!resolvedFile.canonicalPath.startsWith(targetDir.canonicalPath)) {
                        throw SecurityException("非法路径: ${entry.name}")
                    }
                    if (entry.isDirectory) {
                        resolvedFile.mkdirs()
                    } else {
                        resolvedFile.parentFile?.mkdirs()
                        zip.getInputStream(entry).use { input ->
                            BufferedOutputStream(FileOutputStream(resolvedFile)).use { output ->
                                input.copyTo(output, bufferSize = 64 * 1024)
                            }
                        }
                    }
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
