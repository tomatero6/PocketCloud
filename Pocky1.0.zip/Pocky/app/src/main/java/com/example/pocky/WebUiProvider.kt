package com.example.pocky

object WebUiProvider {
    fun getWebUi(): String {
        return """
            <!DOCTYPE html>
            <html>
            <head>
                <title>口袋云服务器 - 管理面板</title>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
                <style>
                    body { 
                        -webkit-touch-callout: none; 
                        -webkit-user-select: none; 
                        user-select: none;
                        font-family: -apple-system, "Microsoft YaHei", sans-serif; 
                        margin: 0; 
                        background: #f0f2f5; 
                        color: #333; 
                        padding-bottom: 80px; 
                        -webkit-tap-highlight-color: transparent;
                    }
                    img {
                        -webkit-touch-callout: default !important;
                        pointer-events: auto !important;
                    }
                    input, textarea, [contenteditable="true"] {
                        -webkit-touch-callout: default !important;
                        -webkit-user-select: text !important;
                        user-select: text !important;
                        pointer-events: auto !important;
                    }
                    .header { background: #1a73e8; color: white; padding: 12px 20px; display: flex; justify-content: space-between; position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
                    .nav-tabs { background: white; display: flex; border-bottom: 1px solid #ddd; padding: 0 20px; }
                    .nav-tab { padding: 12px 20px; cursor: pointer; color: #666; border-bottom: 3px solid transparent; transition: 0.2s; font-weight: 500; }
                    .nav-tab.active { color: #1a73e8; border-bottom-color: #1a73e8; }
                    .container { padding: 15px; max-width: 1200px; margin: 0 auto; }
                    .card { background: white; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); overflow: hidden; margin-top: 10px; }
                    .item { display: flex; align-items: center; padding: 12px 15px; border-bottom: 1px solid #eee; transition: 0.2s; position: relative; }
                    .item:hover { background: #f8f9fa; }
                    .icon { font-size: 22px; margin-right: 12px; width: 30px; text-align: center; }
                    .icon img { width: 30px; height: 30px; object-fit: cover; border-radius: 4px; }
                    .name { flex-grow: 1; cursor: pointer; color: #1a73e8; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-weight: 500; font-size: 14px; }
                    .btn { padding: 6px 12px; border-radius: 4px; border: 1px solid #ddd; background: white; cursor: pointer; font-size: 12px; margin-left: 5px; text-decoration: none; color: #333; transition: 0.2s; }
                    .btn:hover { background: #f0f0f0; }
                    .btn-blue { background: #1a73e8; color: white; border: none; }
                    #path-bar { font-size: 13px; background: #fff; padding: 12px; border-radius: 8px; margin-bottom: 10px; font-family: monospace; border: 1px solid #ddd; word-break: break-all; }
                    
                    /* 预览样式 */
                    #preview-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.9); z-index: 1000; flex-direction: column; align-items: center; justify-content: center; }
                    #preview-content { max-width: 95%; max-height: 80%; display: flex; justify-content: center; align-items: center; }
                    #preview-content img, #preview-content video { max-width: 100%; max-height: 100%; object-fit: contain; }
                    #preview-title { color: white; margin-top: 15px; font-size: 16px; text-align: center; width: 80%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
                    .close-btn { position: absolute; top: 20px; right: 20px; color: white; font-size: 30px; cursor: pointer; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; background: rgba(255,255,255,0.1); border-radius: 50%; }
                    
                    /* 音乐播放小卡片样式 */
                    #music-player {
                        position: fixed;
                        bottom: 10px;
                        left: 10px;
                        right: 10px;
                        background: rgba(255, 255, 255, 0.95);
                        backdrop-filter: blur(10px);
                        border: 1px solid #ddd;
                        border-radius: 12px;
                        padding: 10px 15px;
                        display: none;
                        align-items: center;
                        z-index: 1001;
                        box-shadow: 0 4px 15px rgba(0,0,0,0.15);
                        animation: slideUp 0.3s ease-out;
                    }
                    @keyframes slideUp { from { transform: translateY(100px); } to { transform: translateY(0); } }
                    .player-info { display: flex; align-items: center; flex-grow: 1; min-width: 0; }
                    .player-icon { font-size: 28px; margin-right: 12px; animation: rotate 3s linear infinite; animation-play-state: paused; }
                    .player-playing .player-icon { animation-play-state: running; }
                    @keyframes rotate { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
                    .player-text { overflow: hidden; flex-grow: 1; }
                    .player-name { font-size: 14px; font-weight: bold; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: block; }
                    .player-status { font-size: 11px; color: #1a73e8; }
                    .player-controls { display: flex; align-items: center; gap: 8px; }
                    #player-audio { display: none; }
                    .btn-play-pause { font-size: 24px; cursor: pointer; width: 36px; text-align: center; }
                    .btn-close-player { cursor: pointer; font-size: 20px; color: #999; padding: 5px; }
                    .vol-btn {
                        width: 32px; height: 32px; display: flex; align-items: center; justify-content: center;
                        background: #eee; border-radius: 50%; cursor: pointer; font-size: 18px; color: #666;
                    }
                    .vol-btn:hover { background: #e0e0e0; }
                    #server-vol-controls { display: none; gap: 5px; align-items: center; border-left: 1px solid #ddd; padding-left: 10px; margin-left: 5px; }

                    /* 气泡样式 */
                    #bubble-menu {
                        position: fixed;
                        display: none;
                        background: white;
                        border-radius: 8px;
                        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                        padding: 8px 0;
                        z-index: 2000;
                        min-width: 140px;
                    }
                    .bubble-item {
                        padding: 12px 16px;
                        font-size: 14px;
                        cursor: pointer;
                        color: #333;
                    }
                    .bubble-item:hover {
                        background: #f0f7ff;
                        color: #1a73e8;
                    }
                    
                    /* 重命名弹窗 */
                    #rename-modal {
                        display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; 
                        background: rgba(0,0,0,0.5); z-index: 3000; align-items: center; justify-content: center;
                    }
                    .modal-content {
                        background: white; padding: 20px; border-radius: 12px; width: 85%; max-width: 350px;
                        box-shadow: 0 10px 25px rgba(0,0,0,0.2);
                    }
                    .modal-title { margin-top: 0; margin-bottom: 15px; font-size: 18px; }
                    #rename-input {
                        width: 100%; padding: 12px; box-sizing: border-box; margin-bottom: 20px;
                        border: 1px solid #ddd; border-radius: 6px; font-size: 16px; outline: none;
                    }
                    #rename-input:focus { border-color: #1a73e8; }
                    .modal-btns { display: flex; justify-content: flex-end; gap: 10px; }

                    #file-view, #album-view { display: none; }
                    #file-view.active, #album-view.active { display: block; }

                    /* 选择模式样式 */
                    .item-checkbox { display: none; width: 20px; height: 20px; margin-right: 12px; cursor: pointer; -webkit-user-select: auto; }
                    .select-mode .item-checkbox { display: block; }
                    .select-mode .btn { display: none; }
                    .select-mode .item { cursor: pointer; }
                    
                    #action-bar {
                        position: fixed;
                        bottom: 0;
                        left: 0;
                        right: 0;
                        background: white;
                        padding: 15px;
                        display: none;
                        justify-content: space-around;
                        box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
                        z-index: 1100;
                        border-top: 1px solid #eee;
                    }
                    .action-btn { flex: 1; text-align: center; padding: 10px; cursor: pointer; color: #1a73e8; font-weight: 500; font-size: 14px; }
                    .action-btn:hover { background: #f8f9fa; }
                    .action-btn.danger { color: #d93025; }
                    .action-btn.disabled { color: #ccc; cursor: not-allowed; }

                    .album-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 20px; padding: 15px; }
                    .album-card { background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1); cursor: pointer; transition: 0.3s; position: relative; }
                    .album-card:hover { transform: translateY(-5px); box-shadow: 0 5px 15px rgba(0,0,0,0.2); }
                    .album-cover { width: 100%; aspect-ratio: 1; object-fit: cover; background: #eee; }
                    .album-info { padding: 10px; }
                    .album-name { font-weight: bold; font-size: 14px; margin-bottom: 4px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
                    .album-count { font-size: 12px; color: #888; }
                    .photo-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 5px; padding: 5px; }
                    .photo-item { aspect-ratio: 1; overflow: hidden; cursor: pointer; position: relative; }
                    .photo-item img { width: 100%; height: 100%; object-fit: cover; transition: 0.2s; }
                    .photo-item:hover img { transform: scale(1.05); }

                    /* 拖拽上传样式 */
                    #drop-overlay {
                        display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%;
                        background: rgba(26, 115, 232, 0.3); border: 4px dashed #1a73e8; z-index: 9999;
                        pointer-events: none; align-items: center; justify-content: center;
                    }
                    .drop-message {
                        background: white; padding: 20px 40px; border-radius: 40px;
                        font-size: 20px; color: #1a73e8; font-weight: bold; box-shadow: 0 4px 15px rgba(0,0,0,0.2);
                    }
                </style>
            </head>
            <body>
                <div id="drop-overlay">
                    <div class="drop-message">松手上传文件到当前目录</div>
                </div>

                <div class="header">
                    <b style="font-size: 18px;">口袋云服务器</b>
                    <select id="disk-select" style="background:rgba(255,255,255,0.2); color:white; border:1px solid #fff5; padding: 4px; border-radius: 4px; max-width: 60%;" onchange="loadPath(this.value)"></select>
                </div>
                <div class="nav-tabs">
                    <div class="nav-tab active" onclick="switchView('file')">文件浏览</div>
                    <div class="nav-tab" onclick="switchView('album')">我的相册</div>
                </div>
                <div class="container">
                    <div id="file-view" class="active">
                        <div id="path-bar">正在加载目录...</div>
                        <div style="margin-bottom:10px; display: flex; gap: 10px; overflow-x: auto; padding-bottom: 5px;">
                            <input type="file" id="up-file" style="display:none" multiple onchange="upload()">
                            <button class="btn btn-blue" onclick="document.getElementById('up-file').click()">+ 上传文件</button>
                            <button class="btn" onclick="createFolder()">+ 新建文件夹</button>
                            <button class="btn" id="btn-select" onclick="toggleSelectMode()">选择</button>
                        </div>
                        <div class="card" id="list">正在读取文件列表...</div>
                    </div>
                    <div id="album-view">
                        <div id="album-list-wrapper">
                            <div id="album-list" class="album-grid">正在加载相册...</div>
                        </div>
                        <div id="album-detail-wrapper" style="display:none">
                            <div style="display:flex; align-items:center; margin-bottom:10px; background:white; padding:10px; border-radius:8px; border:1px solid #ddd;">
                                <button class="btn" onclick="backToAlbums()" style="margin-right:15px; font-weight:bold;">← 返回列表</button>
                                <b id="album-title" style="color:#1a73e8; font-size:16px;"></b>
                            </div>
                            <div id="album-photos" class="photo-grid"></div>
                        </div>
                    </div>
                </div>

                <div id="preview-overlay" onclick="closePreview()">
                    <div class="close-btn">&times;</div>
                    <div id="preview-content" onclick="event.stopPropagation()"></div>
                    <div id="preview-title"></div>
                </div>

                <div id="music-player">
                    <div class="player-info">
                        <div class="player-icon">💿</div>
                        <div class="player-text">
                            <span id="player-song-name" class="player-name">正在播放...</span>
                            <span id="player-status-text" class="player-status">正在播放</span>
                        </div>
                    </div>
                    <div class="player-controls">
                        <div id="btn-play-pause" class="btn-play-pause" onclick="togglePlay()">⏸</div>
                        <audio id="player-audio" preload="auto" playsinline></audio>
                        <div id="server-vol-controls">
                            <div class="vol-btn" onclick="controlServerPlayer('vol-down')">−</div>
                            <div class="vol-btn" onclick="controlServerPlayer('vol-up')">+</div>
                        </div>
                        <div class="btn-close-player" onclick="stopMusic()">&times;</div>
                    </div>
                </div>

                <div id="bubble-menu">
                    <div class="bubble-item" id="btn-play-server">用服务端播放</div>
                    <div class="bubble-item" id="btn-rename">重命名</div>
                    <div class="bubble-item" id="btn-unzip" style="display:none">解压</div>
                </div>
                
                <div id="rename-modal">
                    <div class="modal-content">
                        <h3 class="modal-title">重命名</h3>
                        <input type="text" id="rename-input" spellcheck="false" autocomplete="off">
                        <div class="modal-btns">
                            <button class="btn" onclick="closeRenameModal()">取消</button>
                            <button class="btn btn-blue" onclick="confirmRename()">确定</button>
                        </div>
                    </div>
                </div>

                <div id="action-bar">
                    <div class="action-btn" id="btn-copy" onclick="doCopy()">复制</div>
                    <div class="action-btn" id="btn-cut" onclick="doCut()">剪切</div>
                    <div class="action-btn" id="btn-zip-batch" onclick="doZip()">压缩</div>
                    <div class="action-btn" id="btn-paste" style="display:none" onclick="doPaste()">粘贴</div>
                    <div class="action-btn danger" id="btn-batch-delete" style="display:none" onclick="doBatchDelete()">删除</div>
                    <div class="action-btn" onclick="cancelActions()">取消</div>
                </div>

                <script>
                    let currentPath = "";
                    let currentDisk = "";
                    let currentView = "file";
                    let longPressTimer;
                    let lastMenuPath = "";
                    let lastMenuName = "";
                    let lastMenuIsDir = false;
                    let isPlayingOnServer = false;
                    let menuVisibleTime = 0;
                    
                    let isSelectMode = false;
                    let selectedPaths = new Set();
                    let clipboard = { type: null, paths: [] };

                    document.addEventListener('contextmenu', (e) => {
                        const tag = e.target.tagName;
                        if (tag === 'IMG' || tag === 'INPUT' || tag === 'TEXTAREA') return;
                        e.preventDefault();
                    }, false);

                    function formatSize(bytes) {
                        if (bytes === 0) return '0 B';
                        const k = 1024;
                        const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
                        const i = Math.floor(Math.log(bytes) / Math.log(k));
                        return (bytes / Math.pow(k, i)).toFixed(1) + ' ' + sizes[i];
                    }

                    async function init() {
                        try {
                            const r = await fetch('/api/volumes');
                            const volumes = await r.json();
                            const select = document.getElementById('disk-select');
                            volumes.forEach(v => {
                                const opt = document.createElement('option');
                                opt.value = v.path;
                                let name = v.name === "Internal Storage" ? "手机内置存储" : v.name;
                                let total = formatSize(v.totalSize);
                                let used = formatSize(v.totalSize - v.availableSize);
                                opt.textContent = `${'$'}{name} (${'$'}{used}/${'$'}{total})`;

                                if(v.isPrimary) { currentDisk = v.path; currentPath = v.path; opt.selected = true; }
                                select.appendChild(opt);
                            });
                            loadPath(currentPath);
                        } catch(e) { }
                        
                        const audio = document.getElementById('player-audio');
                        audio.onplay = () => {
                            document.getElementById('btn-play-pause').innerText = '⏸';
                            document.getElementById('music-player').classList.add('player-playing');
                        };
                        audio.onpause = () => {
                            document.getElementById('btn-play-pause').innerText = '▶';
                            document.getElementById('music-player').classList.remove('player-playing');
                        };

                        document.addEventListener('click', (e) => {
                            if (Date.now() - menuVisibleTime > 300) {
                                document.getElementById('bubble-menu').style.display = 'none';
                            }
                        });

                        window.addEventListener('scroll', () => {
                            document.getElementById('bubble-menu').style.display = 'none';
                        }, true);

                        document.getElementById('btn-play-server').onclick = async (e) => {
                            e.stopPropagation();
                            document.getElementById('bubble-menu').style.display = 'none';
                            if (lastMenuPath) {
                                try {
                                    const res = await fetch('/api/play-on-server?path=' + encodeURIComponent(lastMenuPath), { method: 'POST' });
                                    if (res.ok) {
                                        const name = lastMenuPath.split('/').pop();
                                        showMusicPlayer("", name, true);
                                    }
                                } catch(e) { console.error(e); }
                            }
                        };
                        
                        document.getElementById('btn-rename').onclick = (e) => {
                            e.stopPropagation();
                            document.getElementById('bubble-menu').style.display = 'none';
                            openRenameModal();
                        };
                        
                        document.getElementById('btn-unzip').onclick = async (e) => {
                            e.stopPropagation();
                            document.getElementById('bubble-menu').style.display = 'none';
                            if (lastMenuPath) {
                                document.getElementById('list').innerHTML = '<div style="padding:40px; text-align:center; color:#1a73e8">正在解压中，请稍候...</div>';
                                try {
                                    const res = await fetch('/api/unzip?path=' + encodeURIComponent(lastMenuPath), { method: 'POST' });
                                    if (res.ok) {
                                        alert('解压完成');
                                        loadPath(currentPath);
                                    } else {
                                        alert('解压失败');
                                        loadPath(currentPath);
                                    }
                                } catch(e) { 
                                    alert('错误: ' + e.message); 
                                    loadPath(currentPath);
                                }
                            }
                        };
                        
                        document.getElementById('rename-input').onkeydown = (e) => {
                            if (e.key === 'Enter') confirmRename();
                            if (e.key === 'Escape') closeRenameModal();
                        };

                        document.getElementById('rename-input').addEventListener('touchstart', (e) => {
                            e.stopPropagation();
                        }, {passive: true});

                        initDragAndDrop();
                    }

                    function initDragAndDrop() {
                        const overlay = document.getElementById('drop-overlay');
                        let dragCounter = 0;

                        window.addEventListener('dragenter', (e) => {
                            e.preventDefault();
                            dragCounter++;
                            if (currentView === 'file') overlay.style.display = 'flex';
                        });

                        window.addEventListener('dragleave', (e) => {
                            e.preventDefault();
                            dragCounter--;
                            if (dragCounter === 0) overlay.style.display = 'none';
                        });

                        window.addEventListener('dragover', (e) => {
                            e.preventDefault();
                        });

                        window.addEventListener('drop', (e) => {
                            e.preventDefault();
                            dragCounter = 0;
                            overlay.style.display = 'none';
                            if (currentView !== 'file') return;
                            
                            const files = e.dataTransfer.files;
                            if (files.length > 0) {
                                upload(files);
                            }
                        });
                    }

                    function openRenameModal() {
                        const modal = document.getElementById('rename-modal');
                        const input = document.getElementById('rename-input');
                        input.value = lastMenuName;
                        modal.style.display = 'flex';
                        setTimeout(() => {
                            input.focus();
                            let lastDot = lastMenuName.lastIndexOf('.');
                            if (lastDot > 0 && !lastMenuIsDir) {
                                input.setSelectionRange(0, lastDot);
                            } else {
                                input.select();
                            }
                        }, 300);
                    }

                    function closeRenameModal() {
                        document.getElementById('rename-modal').style.display = 'none';
                    }

                    async function confirmRename() {
                        const newName = document.getElementById('rename-input').value;
                        if (!newName || newName === lastMenuName) {
                            closeRenameModal();
                            return;
                        }
                        try {
                            const res = await fetch('/api/rename?path=' + encodeURIComponent(lastMenuPath) + '&newName=' + encodeURIComponent(newName), { method: 'POST' });
                            if (res.ok) {
                                closeRenameModal();
                                loadPath(currentPath);
                            } else {
                                const msg = await res.text();
                                alert('重命名失败: ' + msg);
                            }
                        } catch(e) { alert('请求出错: ' + e.message); }
                    }

                    function switchView(view) {
                        if (isSelectMode) toggleSelectMode();
                        currentView = view;
                        document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
                        document.querySelectorAll('#file-view, #album-view').forEach(v => v.classList.remove('active'));
                        if(view === 'file') {
                            document.querySelector('.nav-tab:nth-child(1)').classList.add('active');
                            document.getElementById('file-view').classList.add('active');
                        } else {
                            document.querySelector('.nav-tab:nth-child(2)').classList.add('active');
                            document.getElementById('album-view').classList.add('active');
                            backToAlbums(); 
                        }
                    }

                    function toggleSelectMode() {
                        isSelectMode = !isSelectMode;
                        selectedPaths.clear();
                        const list = document.getElementById('list');
                        const btnSelect = document.getElementById('btn-select');
                        
                        if (isSelectMode) {
                            list.classList.add('select-mode');
                            btnSelect.innerText = '取消选择';
                        } else {
                            list.classList.remove('select-mode');
                            btnSelect.innerText = '选择';
                            document.querySelectorAll('.item-checkbox').forEach(cb => cb.checked = false);
                        }
                        updateActionBar();
                    }

                    function updateActionBar() {
                        const bar = document.getElementById('action-bar');
                        const hasSelected = selectedPaths.size > 0;
                        const hasClipboard = clipboard.type !== null;

                        if (isSelectMode || hasClipboard) {
                            bar.style.display = 'flex';
                        } else {
                            bar.style.display = 'none';
                            return;
                        }

                        document.getElementById('btn-copy').style.display = isSelectMode ? 'block' : 'none';
                        document.getElementById('btn-cut').style.display = isSelectMode ? 'block' : 'none';
                        document.getElementById('btn-zip-batch').style.display = isSelectMode ? 'block' : 'none';
                        document.getElementById('btn-batch-delete').style.display = isSelectMode ? 'block' : 'none';
                        document.getElementById('btn-paste').style.display = hasClipboard ? 'block' : 'none';

                        document.getElementById('btn-copy').className = 'action-btn' + (hasSelected ? '' : ' disabled');
                        document.getElementById('btn-cut').className = 'action-btn' + (hasSelected ? '' : ' disabled');
                        document.getElementById('btn-zip-batch').className = 'action-btn' + (hasSelected ? '' : ' disabled');
                        document.getElementById('btn-batch-delete').className = 'action-btn danger' + (hasSelected ? '' : ' disabled');
                    }

                    function cancelActions() {
                        if (isSelectMode) {
                            toggleSelectMode();
                        } else {
                            clipboard = { type: null, paths: [] };
                            updateActionBar();
                        }
                    }

                    function handleItemSelect(path) {
                        if (selectedPaths.has(path)) {
                            selectedPaths.delete(path);
                        } else {
                            selectedPaths.add(path);
                        }
                        updateActionBar();
                    }

                    function doCopy() {
                        if (selectedPaths.size === 0) return;
                        clipboard = { type: 'copy', paths: Array.from(selectedPaths) };
                        toggleSelectMode();
                        alert('已复制 ' + clipboard.paths.length + ' 个项目');
                    }

                    function doCut() {
                        if (selectedPaths.size === 0) return;
                        clipboard = { type: 'cut', paths: Array.from(selectedPaths) };
                        toggleSelectMode();
                        alert('已剪切 ' + clipboard.paths.length + ' 个项目');
                    }

                    async function doZip() {
                        if (selectedPaths.size === 0) return;
                        const paths = Array.from(selectedPaths);
                        const params = new URLSearchParams();
                        paths.forEach(p => params.append('from', p));
                        params.append('to', currentPath);
                        
                        document.getElementById('list').innerHTML = '<div style="padding:40px; text-align:center; color:#1a73e8">正在压缩中，请稍候...</div>';
                        try {
                            const res = await fetch('/api/zip?' + params.toString(), { method: 'POST' });
                            if (res.ok) {
                                alert('压缩完成');
                                toggleSelectMode();
                                loadPath(currentPath);
                            } else {
                                alert('压缩失败');
                                loadPath(currentPath);
                            }
                        } catch(e) { 
                            alert('错误: ' + e.message); 
                            loadPath(currentPath);
                        }
                    }

                    async function doPaste() {
                        if (!clipboard.type || clipboard.paths.length === 0) return;
                        const api = clipboard.type === 'copy' ? '/api/copy' : '/api/move';
                        const params = new URLSearchParams();
                        clipboard.paths.forEach(p => params.append('from', p));
                        params.append('to', currentPath);
                        
                        try {
                            const res = await fetch(api + '?' + params.toString(), { method: 'POST' });
                            if (res.ok) {
                                clipboard = { type: null, paths: [] };
                                loadPath(currentPath);
                            } else {
                                alert('操作失败');
                            }
                        } catch(e) { alert('错误: ' + e.message); }
                    }

                    async function doBatchDelete() {
                        if (selectedPaths.size === 0) return;
                        if (!confirm('确定删除选中的 ' + selectedPaths.size + ' 个项目吗？')) return;
                        const paths = Array.from(selectedPaths);
                        try {
                            const promises = paths.map(p => fetch('/api/delete?path=' + encodeURIComponent(p), { method: 'DELETE' }));
                            await Promise.all(promises);
                            toggleSelectMode();
                            loadPath(currentPath);
                        } catch(e) { alert('删除失败: ' + e.message); }
                    }

                    async function loadPath(path) {
                        currentPath = path;
                        document.getElementById('path-bar').innerText = path;
                        const r = await fetch('/api/files?path=' + encodeURIComponent(path));
                        const files = await r.json();
                        let html = '';
                        if (path.length > currentDisk.length) {
                            let lastSlash = path.lastIndexOf('/');
                            let parent = path.substring(0, lastSlash === 0 ? 1 : lastSlash);
                            html += `<div class="item" onclick="loadPath('${'$'}{parent}')"><span class="icon">↩</span><span class="name">.. 返回上一级</span></div>`;
                        }
                        files.forEach(f => {
                            if (f.isSystem) return;
                            const pathEscaped = f.path.replace(/'/g, "\\'");
                            const nameEscaped = f.name.replace(/'/g, "\\'");
                            const pathJson = JSON.stringify(f.path);
                            const isChecked = selectedPaths.has(f.path) ? "checked" : "";
                            
                            html += `<div class="item" 
                                onmousedown="handleMouseDown(event, '${'$'}{pathEscaped}', '${'$'}{nameEscaped}', ${'$'}{f.isDir})" 
                                ontouchstart="handleMouseDown(event, '${'$'}{pathEscaped}', '${'$'}{nameEscaped}', ${'$'}{f.isDir})" 
                                onmouseup="handleMouseUp()" 
                                ontouchend="handleMouseUp()" 
                                oncontextmenu="handleContextMenu(event, '${'$'}{pathEscaped}', '${'$'}{nameEscaped}', ${'$'}{f.isDir})"
                                onclick='if(isSelectMode){ let cb=this.querySelector(".item-checkbox"); cb.checked=!cb.checked; handleItemSelect(${'$'}{pathJson}); }'>`;
                            
                            html += `<input type="checkbox" class="item-checkbox" ${'$'}{isChecked} onclick='event.stopPropagation(); handleItemSelect(${'$'}{pathJson})'>`;
                            
                            // 优化：列表页也显示缩略图预览
                            let iconHtml = f.isDir ? '📁' : getFileIcon(f.name);
                            if (!f.isDir && (isImgExt(f.name) || isVideoExt(f.name))) {
                                iconHtml = `<img src="/api/thumbnail?size=60&path=${'$'}{encodeURIComponent(f.path)}" loading="lazy">`;
                            }
                            
                            html += '<span class="icon">' + iconHtml + '</span>';
                            html += '<span class="name" onclick=\'if(!isSelectMode) handleItemClick(' + pathJson + ',' + f.isDir + ',' + JSON.stringify(f.name) + '); event.stopPropagation();\'>' + f.name + '</span>';
                            
                            if(!f.isDir) html += '<a class="btn" href="/api/download?path=' + encodeURIComponent(f.path) + '">下载</a>';
                            html += '<button class="btn" style="color:#d93025" onclick=\'del(' + pathJson + '); event.stopPropagation();\'>删除</button>';
                            html += '</div>';
                        });
                        document.getElementById('list').innerHTML = html || '<div style="padding:30px; text-align:center; color:#999">文件夹为空</div>';
                        
                        if (isSelectMode) {
                            document.getElementById('list').classList.add('select-mode');
                        }
                        updateActionBar();
                    }

                    function handleMouseDown(e, path, name, isDir) {
                        if (isSelectMode) return;
                        const x = e.clientX || (e.touches && e.touches[0].clientX);
                        const y = e.clientY || (e.touches && e.touches[0].clientY);
                        longPressTimer = setTimeout(() => {
                            showBubbleMenu(x, y, path, name, isDir);
                        }, 600);
                    }

                    function handleMouseUp() {
                        clearTimeout(longPressTimer);
                    }

                    function handleContextMenu(e, path, name, isDir) {
                        if (isSelectMode) return;
                        if (e.target.tagName === 'IMG') return;
                        e.preventDefault();
                        showBubbleMenu(e.clientX, e.clientY, path, name, isDir);
                    }

                    function showBubbleMenu(x, y, path, name, isDir) {
                        const menu = document.getElementById('bubble-menu');
                        lastMenuPath = path;
                        lastMenuName = name;
                        lastMenuIsDir = isDir;
                        
                        const isMusic = isAudioExt(name);
                        document.getElementById('btn-play-server').style.display = isMusic ? 'block' : 'none';
                        
                        const isZip = isZipExt(name);
                        document.getElementById('btn-unzip').style.display = isZip ? 'block' : 'none';
                        
                        menu.style.display = 'block';
                        let left = x;
                        if (left + 150 > window.innerWidth) left = window.innerWidth - 160;
                        menu.style.left = left + 'px';
                        let top = y - 50;
                        if (top < 10) top = 10;
                        menu.style.top = top + 'px';
                        menuVisibleTime = Date.now();
                        if (navigator.vibrate) navigator.vibrate(50);
                    }

                    function getFileIcon(name) {
                        if (isImgExt(name)) return '🖼️';
                        if (isVideoExt(name)) return '🎬';
                        if (isAudioExt(name)) return '🎵';
                        if (isZipExt(name)) return '📦';
                        return '📄';
                    }
                    function isImgExt(name) {
                        const ext = name.split('.').pop().toLowerCase();
                        return ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'ico', 'heic', 'heif', 'avif', 'tiff', 'tif'].includes(ext);
                    }
                    function isVideoExt(name) {
                        const ext = name.split('.').pop().toLowerCase();
                        return ['mp4', 'mov', 'm4v', 'mkv', 'webm', 'avi'].includes(ext);
                    }
                    function isAudioExt(name) {
                        const ext = name.split('.').pop().toLowerCase();
                        return ['mp3', 'wav', 'aac', 'm4a', 'flac', 'ogg'].includes(ext);
                    }
                    function isZipExt(name) {
                        const ext = name.split('.').pop().toLowerCase();
                        return ['zip'].includes(ext);
                    }

                    function handleItemClick(path, isDir, name) {
                        if(isDir) loadPath(path);
                        else previewFile(path, name);
                    }

                    function previewFile(path, name) {
                        const url = '/api/view?path=' + encodeURIComponent(path) + '&v=' + Date.now() + '&ext=.' + name.split('.').pop();
                        if (isAudioExt(name)) {
                            showMusicPlayer(url, name);
                            return; 
                        }
                        const overlay = document.getElementById('preview-overlay');
                        const content = document.getElementById('preview-content');
                        const title = document.getElementById('preview-title');
                        content.innerHTML = '';
                        title.innerText = name;
                        if (isImgExt(name)) {
                            content.innerHTML = `<img src="${'$'}{url}">`;
                        } else if (isVideoExt(name)) {
                            content.innerHTML = `<video src="${'$'}{url}" controls autoplay playsinline preload="auto"></video>`;
                        } else {
                            window.location.href = '/api/download?path=' + encodeURIComponent(path);
                            return;
                        }
                        overlay.style.display = 'flex';
                        document.body.style.overflow = 'hidden';
                    }

                    function showMusicPlayer(url, name, isServer = false) {
                        const player = document.getElementById('music-player');
                        const audio = document.getElementById('player-audio');
                        const nameSpan = document.getElementById('player-song-name');
                        const statusSpan = document.getElementById('player-status-text');
                        const volControls = document.getElementById('server-vol-controls');
                        isPlayingOnServer = isServer;
                        player.style.display = 'flex';
                        nameSpan.innerText = name;
                        if (isServer) {
                            audio.pause();
                            audio.src = "";
                            statusSpan.innerText = "服务端播放中";
                            volControls.style.display = 'flex';
                            document.getElementById('btn-play-pause').innerText = '⏸';
                            player.classList.add('player-playing');
                        } else {
                            statusSpan.innerText = "正在播放";
                            volControls.style.display = 'none';
                            const fullUrl = window.location.origin + url;
                            if (audio.src !== fullUrl) audio.src = url;
                            audio.play().catch(e => console.error("Playback failed:", e));
                        }
                    }

                    async function controlServerPlayer(action) {
                        await fetch('/api/player-control?action=' + action, { method: 'POST' });
                    }

                    async function togglePlay() {
                        if (isPlayingOnServer) {
                            const btn = document.getElementById('btn-play-pause');
                            const player = document.getElementById('music-player');
                            if (btn.innerText === '⏸') {
                                btn.innerText = '▶';
                                player.classList.remove('player-playing');
                            } else {
                                btn.innerText = '⏸';
                                player.classList.add('player-playing');
                            }
                            await controlServerPlayer('toggle');
                        } else {
                            const audio = document.getElementById('player-audio');
                            if (audio.paused) audio.play();
                            else audio.pause();
                        }
                    }

                    async function stopMusic() {
                        const player = document.getElementById('music-player');
                        const audio = document.getElementById('player-audio');
                        if (isPlayingOnServer) {
                            await controlServerPlayer('stop');
                            isPlayingOnServer = false;
                        }
                        audio.pause();
                        audio.src = "";
                        player.style.display = 'none';
                    }

                    function closePreview() {
                        const overlay = document.getElementById('preview-overlay');
                        const content = document.getElementById('preview-content');
                        content.innerHTML = ''; 
                        overlay.style.display = 'none';
                        document.body.style.overflow = '';
                    }

                    async function loadAlbums() {
                        const albumList = document.getElementById('album-list');
                        albumList.innerHTML = '<div style="padding:40px; text-align:center; grid-column: 1/-1; color:#999">正在扫描相册...</div>';
                        try {
                            const r = await fetch('/api/albums');
                            const albums = await r.json();
                            let html = '';
                            albums.forEach(album => {
                                // 优化：相册封面使用缩略图
                                html += `
                                    <div class="album-card" onclick="openAlbum('${'$'}{encodeURIComponent(album.fullPath)}', '${'$'}{album.name}')">
                                        <img class="album-cover" src="/api/thumbnail?path=${'$'}{encodeURIComponent(album.firstImagePath)}&size=400" loading="lazy">
                                        <div class="album-info">
                                            <div class="album-name">${'$'}{album.name}</div>
                                            <div class="album-count">${'$'}{album.count} 张照片</div>
                                        </div>
                                    </div>
                                `;
                            });
                            albumList.innerHTML = html || '<div style="padding:40px; text-align:center; grid-column: 1/-1; color:#999">未发现相册</div>';
                        } catch(e) {
                            albumList.innerHTML = '<div style="padding:40px; text-align:center; grid-column: 1/-1; color:red">加载相册失败</div>';
                        }
                    }
                    
                    async function openAlbum(path, name) {
                        const listWrapper = document.getElementById('album-list-wrapper');
                        const detailWrapper = document.getElementById('album-detail-wrapper');
                        const photoDiv = document.getElementById('album-photos');
                        const titleB = document.getElementById('album-title');
                        listWrapper.style.display = 'none';
                        detailWrapper.style.display = 'block';
                        titleB.innerText = name;
                        photoDiv.innerHTML = '<div style="padding:40px; text-align:center; color:#999">正在加载照片...</div>';
                        try {
                            const r = await fetch('/api/photos?path=' + encodeURIComponent(decodeURIComponent(path)));
                            const photos = await r.json();
                            let html = '';
                            photos.forEach(f => {
                                let contentHtml = '';
                                if (isAudioExt(f.name)) {
                                    contentHtml = '<div style="font-size:40px; display:flex; align-items:center; justify-content:center; height:100%; background:#f8f9fa;">🎵</div>';
                                } else {
                                    // 核心优化：照片墙使用缩略图
                                    contentHtml = `<img src="/api/thumbnail?path=${'$'}{encodeURIComponent(f.path)}&size=300" loading="lazy">`;
                                }
                                const pathEscaped = f.path.replace(/'/g, "\\'");
                                const nameEscaped = f.name.replace(/'/g, "\\'");
                                html += `
                                    <div class="photo-item" onclick='handleItemClick(${'$'}{JSON.stringify(f.path)}, false, ${'$'}{JSON.stringify(f.name)})'
                                         onmousedown="handleMouseDown(event, '${'$'}{pathEscaped}', '${'$'}{nameEscaped}', false)" 
                                         ontouchstart="handleMouseDown(event, '${'$'}{pathEscaped}', '${'$'}{nameEscaped}', false)" 
                                         onmouseup="handleMouseUp()" 
                                         ontouchend="handleMouseUp()" 
                                         oncontextmenu="handleContextMenu(event, '${'$'}{pathEscaped}', '${'$'}{nameEscaped}', false)">
                                        ${'$'}{contentHtml}
                                    </div>
                                `;
                            });
                            photoDiv.innerHTML = html || '<div style="padding:40px; text-align:center; color:#999">相册为空</div>';
                        } catch(e) {
                            photoDiv.innerHTML = '<div style="padding:40px; text-align:center; color:red">加载照片失败</div>';
                        }
                    }
                    
                    function backToAlbums() {
                        document.getElementById('album-list-wrapper').style.display = 'block';
                        document.getElementById('album-detail-wrapper').style.display = 'none';
                        loadAlbums();
                    }

                    async function upload(droppedFiles) {
                        const fileInput = document.getElementById('up-file');
                        const files = droppedFiles ? Array.from(droppedFiles) : Array.from(fileInput.files);
                        if(!files.length) return;
                        fileInput.value = "";
                        const listDiv = document.getElementById('list');
                        for (let i = 0; i < files.length; i++) {
                            const file = files[i];
                            listDiv.innerHTML = '<div style="padding:20px; text-align:center">正在准备: ' + file.name + '...</div>';
                            try {
                                const statusRes = await fetch('/api/upload/status?path=' + encodeURIComponent(currentPath) + '&name=' + encodeURIComponent(file.name));
                                const status = await statusRes.json();
                                let uploadedSize = status.size || 0;
                                if (uploadedSize >= file.size && file.size > 0) continue;
                                const chunkSize = 10 * 1024 * 1024;
                                let offset = uploadedSize;
                                while (offset < file.size) {
                                    const chunk = file.slice(offset, offset + chunkSize);
                                    const fd = new FormData();
                                    fd.append('file', chunk, file.name);
                                    const res = await fetch('/api/upload?path=' + encodeURIComponent(currentPath) + '&offset=' + offset, { method: 'POST', body: fd });
                                    if(!res.ok) throw new Error("Upload failed");
                                    offset += chunk.size;
                                    listDiv.innerHTML = '<div style="padding:20px; text-align:center">正在上传: ' + file.name + ' (' + Math.round(offset/file.size*100) + '%)</div>';
                                }
                            } catch (e) { alert("失败: " + e.message); break; }
                        }
                        loadPath(currentPath);
                    }
                    async function del(path) { if(confirm('确定删除吗？')) { await fetch('/api/delete?path=' + encodeURIComponent(path), {method:'DELETE'}); loadPath(currentPath); } }
                    async function createFolder() { const name = prompt("名称:"); if (name) { await fetch('/api/mkdir?path=' + encodeURIComponent(currentPath) + '&name=' + encodeURIComponent(name), {method:'POST'}); loadPath(currentPath); } }
                    
                    init();
                </script>
            </body>
            </html>
        """.trimIndent()
    }
}
