package com.example.pocky

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.createBitmap
import androidx.core.graphics.set
import androidx.core.net.toUri
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.launch
import java.io.File
import java.text.DecimalFormat

class MainActivity : ComponentActivity() {

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // 开启高刷支持
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.attributes.preferredDisplayModeId = 
                display?.supportedModes?.maxByOrNull { it.refreshRate }?.modeId ?: 0
        }

        checkPermissions()
        setContent {
            MaterialTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    MainScreen()
                }
            }
        }
    }

    private fun checkPermissions() {
        val permissions = mutableListOf<String>()
        
        // 存储权限逻辑
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                intent.data = "package:$packageName".toUri()
                startActivity(intent)
            }
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }

        // Android 13+ 通知权限
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (permissions.isNotEmpty()) {
            requestPermissionLauncher.launch(permissions.toTypedArray())
        }
    }
}

@Composable
fun MainScreen() {
    val selectedTab = remember { mutableIntStateOf(0) }
    val context = LocalContext.current
    val repository = remember { MediaRepository(context) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab.intValue == 0,
                    onClick = { selectedTab.intValue = 0 },
                    label = { Text(stringResource(R.string.gallery)) },
                    icon = { Icon(Icons.Default.Image, contentDescription = null) }
                )
                NavigationBarItem(
                    selected = selectedTab.intValue == 1,
                    onClick = { selectedTab.intValue = 1 },
                    label = { Text(stringResource(R.string.files)) },
                    icon = { Icon(Icons.Default.Folder, contentDescription = null) }
                )
                NavigationBarItem(
                    selected = selectedTab.intValue == 2,
                    onClick = { selectedTab.intValue = 2 },
                    label = { Text(stringResource(R.string.server)) },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null) }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            when (selectedTab.intValue) {
                0 -> GalleryScreen(repository)
                1 -> FileExplorerScreen(repository)
                2 -> ServerScreen(repository)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GalleryScreen(repository: MediaRepository) {
    val context = LocalContext.current
    val volumes = remember { repository.getStorageVolumes() }
    var currentVolume by remember { mutableStateOf<StorageVolumeInfo?>(null) }
    var selectedFolder by remember { mutableStateOf<AlbumFolder?>(null) }
    var showVolumePicker by remember { mutableStateOf(false) }
    val refreshTrigger by ServerEvents.refreshTrigger

    LaunchedEffect(volumes) {
        if (currentVolume == null && volumes.isNotEmpty()) {
            currentVolume = volumes.find { it.isPrimary } ?: volumes.first()
        }
    }

    val folders by produceState(initialValue = emptyList(), key1 = currentVolume, key2 = refreshTrigger) {
        currentVolume?.let { volume ->
            value = if (volume.isPrimary) {
                repository.getInternalAlbumFolders()
            } else {
                repository.scanExternalAlbumFolders(volume.path)
            }
        }
    }

    Column {
        if (selectedFolder == null) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = currentVolume?.name ?: stringResource(R.string.loading),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = { showVolumePicker = true }) {
                    Icon(Icons.Default.Storage, contentDescription = stringResource(R.string.switch_disk))
                }
            }

            if (showVolumePicker) {
                AlertDialog(
                    onDismissRequest = { showVolumePicker = false },
                    title = { Text(stringResource(R.string.select_gallery_source)) },
                    text = {
                        Column {
                            volumes.forEach { volume ->
                                ListItem(
                                    headlineContent = { Text(volume.name) },
                                    supportingContent = { Text(volume.path, fontSize = 10.sp) },
                                    modifier = Modifier.clickable {
                                        currentVolume = volume
                                        showVolumePicker = false
                                    }
                                )
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = { showVolumePicker = false }) { Text(stringResource(R.string.cancel)) } }
                )
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(folders, key = { it.fullPath }) { folder ->
                    AlbumFolderItem(folder) {
                        selectedFolder = folder
                    }
                }
            }
        } else {
            val photos by produceState(initialValue = emptyList(), key1 = selectedFolder, key2 = refreshTrigger) {
                value = repository.getPhotosInDirectory(selectedFolder!!.fullPath)
            }

            TopAppBar(
                title = { Text(selectedFolder!!.name) },
                navigationIcon = {
                    IconButton(onClick = { selectedFolder = null }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                }
            )
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.fillMaxSize()
            ) {
                items(photos, key = { it.id }) { photo ->
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(photo.path)
                            .crossfade(true)
                            .diskCachePolicy(CachePolicy.ENABLED)
                            .memoryCachePolicy(CachePolicy.ENABLED)
                            .build(),
                        contentDescription = null,
                        modifier = Modifier.aspectRatio(1f).padding(1.dp),
                        contentScale = ContentScale.Crop
                    )
                }
            }
            BackHandler { selectedFolder = null }
        }
    }
}

data class AppClipboard(
    val type: String, // "copy" or "cut"
    val paths: List<String>
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun FileExplorerScreen(repository: MediaRepository) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val volumes = remember { repository.getStorageVolumes() }
    var currentPath by remember { mutableStateOf("") }
    val showVolumePicker = remember { mutableStateOf(false) }
    val refreshTrigger by ServerEvents.refreshTrigger
    
    var isSelectMode by remember { mutableStateOf(false) }
    val selectedPaths = remember { mutableStateListOf<String>() }
    val clipboard = remember { mutableStateOf<AppClipboard?>(null) }
    
    val showMkdirDialog = remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(volumes) {
        if (currentPath.isEmpty() && volumes.isNotEmpty()) {
            currentPath = volumes.first().path
        }
    }

    val files by produceState(initialValue = emptyList<MediaItem>(), key1 = currentPath, key2 = refreshTrigger) {
        if (currentPath.isNotEmpty()) {
            value = repository.getFiles(currentPath)
        }
    }

    val regularFiles = remember(files) { files.filter { !it.isSystem } }
    val systemFiles = remember(files) { files.filter { it.isSystem } }

    fun toggleSelection(path: String) {
        if (selectedPaths.contains(path)) {
            selectedPaths.remove(path)
            if (selectedPaths.isEmpty()) isSelectMode = false
        } else {
            selectedPaths.add(path)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isSelectMode) stringResource(R.string.selected_count, selectedPaths.size) else currentPath,
                        style = if (isSelectMode) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodySmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    if (isSelectMode) {
                        IconButton(onClick = { 
                            isSelectMode = false
                            selectedPaths.clear()
                        }) {
                            Icon(Icons.Default.Close, contentDescription = stringResource(R.string.cancel))
                        }
                    }
                },
                actions = {
                    if (!isSelectMode) {
                        IconButton(onClick = { showMkdirDialog.value = true }) {
                            Icon(Icons.Default.CreateNewFolder, contentDescription = stringResource(R.string.new_folder))
                        }
                        IconButton(onClick = { showVolumePicker.value = true }) {
                            Icon(Icons.Default.Storage, contentDescription = stringResource(R.string.switch_disk))
                        }
                    } else {
                        IconButton(onClick = {
                            val allPaths = regularFiles.map { it.path }
                            if (selectedPaths.size == allPaths.size) {
                                selectedPaths.clear()
                                isSelectMode = false
                            } else {
                                selectedPaths.clear()
                                selectedPaths.addAll(allPaths)
                            }
                        }) {
                            Icon(Icons.Default.SelectAll, contentDescription = stringResource(R.string.select_all))
                        }
                    }
                }
            )
        },
        bottomBar = {
            AnimatedVisibility(
                visible = isSelectMode || clipboard.value != null,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                BottomAppBar(
                    actions = {
                        if (isSelectMode) {
                            ActionItem(icon = Icons.Default.ContentCopy, label = stringResource(R.string.copy)) {
                                clipboard.value = AppClipboard("copy", selectedPaths.toList())
                                isSelectMode = false
                                selectedPaths.clear()
                            }
                            ActionItem(icon = Icons.Default.ContentCut, label = stringResource(R.string.cut)) {
                                clipboard.value = AppClipboard("cut", selectedPaths.toList())
                                isSelectMode = false
                                selectedPaths.clear()
                            }
                            ActionItem(icon = Icons.Default.Archive, label = stringResource(R.string.zip)) {
                                scope.launch {
                                    val zipFile = File(currentPath, "archive_${System.currentTimeMillis()}.zip")
                                    val success = repository.zip(selectedPaths.map { File(it) }, zipFile)
                                    if (success) {
                                        ServerEvents.refreshTrigger.value++
                                        isSelectMode = false
                                        selectedPaths.clear()
                                        Toast.makeText(context, R.string.zip_success, Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                            ActionItem(icon = Icons.Default.Delete, label = stringResource(R.string.delete), isDanger = true) {
                                scope.launch {
                                    var count = 0
                                    selectedPaths.forEach { if (repository.delete(it)) count++ }
                                    ServerEvents.refreshTrigger.value++
                                    isSelectMode = false
                                    selectedPaths.clear()
                                    Toast.makeText(context, context.getString(R.string.deleted_count, count), Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                        
                        if (clipboard.value != null && !isSelectMode) {
                            Button(
                                onClick = {
                                    scope.launch {
                                        val currentClipboard = clipboard.value
                                        if (currentClipboard != null) {
                                            val success = if (currentClipboard.type == "copy") {
                                                repository.copy(currentClipboard.paths, currentPath)
                                            } else {
                                                repository.move(currentClipboard.paths, currentPath)
                                            }
                                            if (success) {
                                                if (currentClipboard.type == "cut") clipboard.value = null
                                                ServerEvents.refreshTrigger.value++
                                                Toast.makeText(context, R.string.paste_success, Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                },
                                modifier = Modifier.padding(start = 16.dp)
                            ) {
                                Icon(Icons.Default.ContentPaste, null)
                                Spacer(Modifier.width(8.dp))
                                Text(stringResource(R.string.paste_here))
                            }
                        }
                    },
                    floatingActionButton = {
                        if (clipboard.value != null && !isSelectMode) {
                            FloatingActionButton(
                                onClick = { clipboard.value = null },
                                containerColor = MaterialTheme.colorScheme.secondaryContainer
                            ) {
                                Icon(Icons.Default.Clear, contentDescription = stringResource(R.string.clear_clipboard))
                            }
                        }
                    }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            Column {
                if (showVolumePicker.value) {
                    AlertDialog(
                        onDismissRequest = { showVolumePicker.value = false },
                        title = { Text(stringResource(R.string.select_storage)) },
                        text = {
                            Column {
                                volumes.forEach { volume ->
                                    ListItem(
                                        headlineContent = { Text(volume.name) },
                                        supportingContent = { Text(volume.path, fontSize = 10.sp) },
                                        modifier = Modifier.clickable {
                                            currentPath = volume.path
                                            showVolumePicker.value = false
                                        }
                                    )
                                }
                            }
                        },
                        confirmButton = { TextButton(onClick = { showVolumePicker.value = false }) { Text(stringResource(R.string.cancel)) } }
                    )
                }
                
                if (showMkdirDialog.value) {
                    var folderName by remember { mutableStateOf("") }
                    AlertDialog(
                        onDismissRequest = { showMkdirDialog.value = false },
                        title = { Text(stringResource(R.string.new_folder)) },
                        text = {
                            OutlinedTextField(
                                value = folderName,
                                onValueChange = { folderName = it },
                                label = { Text(stringResource(R.string.folder_name)) },
                                singleLine = true
                            )
                        },
                        confirmButton = {
                            TextButton(onClick = {
                                if (folderName.isNotEmpty()) {
                                    scope.launch {
                                        if (repository.mkdir(currentPath, folderName)) {
                                            ServerEvents.refreshTrigger.value++
                                        }
                                        showMkdirDialog.value = false
                                    }
                                }
                            }) { Text(stringResource(R.string.create)) }
                        },
                        dismissButton = {
                            TextButton(onClick = { showMkdirDialog.value = false }) { Text(stringResource(R.string.cancel)) }
                        }
                    )
                }
                
                showRenameDialog?.let { path ->
                    var newName by remember { mutableStateOf(File(path).name) }
                    AlertDialog(
                        onDismissRequest = { showRenameDialog = null },
                        title = { Text(stringResource(R.string.rename)) },
                        text = {
                            OutlinedTextField(
                                value = newName,
                                onValueChange = { newName = it },
                                label = { Text(stringResource(R.string.new_name)) },
                                singleLine = true
                            )
                        },
                        confirmButton = {
                            TextButton(onClick = {
                                if (newName.isNotEmpty() && newName != File(path).name) {
                                    scope.launch {
                                        if (repository.rename(path, newName)) {
                                            ServerEvents.refreshTrigger.value++
                                        }
                                        showRenameDialog = null
                                    }
                                } else {
                                    showRenameDialog = null
                                }
                            }) { Text(stringResource(R.string.confirm)) }
                        },
                        dismissButton = {
                            TextButton(onClick = { showRenameDialog = null }) { Text(stringResource(R.string.cancel)) }
                        }
                    )
                }

                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    if (currentPath.isNotEmpty() && !volumes.any { it.path == currentPath }) {
                        item(key = "parent_dir") {
                            ListItem(
                                headlineContent = { Text(stringResource(R.string.parent_directory)) },
                                leadingContent = { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) },
                                modifier = Modifier.clickable { 
                                    if (isSelectMode) {
                                        isSelectMode = false
                                        selectedPaths.clear()
                                    }
                                    currentPath = File(currentPath).parent ?: currentPath 
                                }
                            )
                        }
                    }
                    
                    items(regularFiles, key = { it.id }) { item ->
                        val isSelected = selectedPaths.contains(item.path)
                        ListItem(
                            headlineContent = { Text(item.name) },
                            supportingContent = { 
                                if (!item.isDir) {
                                    Text("${DecimalFormat("#.##").format(item.size.toDouble() / (1024 * 1024))} MB", fontSize = 12.sp)
                                }
                            },
                            leadingContent = { 
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (item.isDir) Icons.Default.Folder else Icons.Default.Description, 
                                        contentDescription = null,
                                        tint = if (isSelected) MaterialTheme.colorScheme.primary else LocalContentColor.current
                                    )
                                    if (isSelectMode) {
                                        Checkbox(
                                            checked = isSelected,
                                            onCheckedChange = { toggleSelection(item.path) },
                                            modifier = Modifier.size(24.dp).alpha(0.8f)
                                        )
                                    }
                                }
                            },
                            trailingContent = {
                                if (!isSelectMode) {
                                    var showMenu by remember { mutableStateOf(false) }
                                    Box {
                                        IconButton(onClick = { showMenu = true }) {
                                            Icon(Icons.Default.MoreVert, null)
                                        }
                                        DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                                            DropdownMenuItem(
                                                text = { Text(stringResource(R.string.rename)) },
                                                onClick = {
                                                    showMenu = false
                                                    showRenameDialog = item.path
                                                },
                                                leadingIcon = { Icon(Icons.Default.Edit, null) }
                                            )
                                            if (item.name.lowercase().endsWith(".zip")) {
                                                DropdownMenuItem(
                                                    text = { Text(stringResource(R.string.unzip)) },
                                                    onClick = {
                                                        showMenu = false
                                                        scope.launch {
                                                            val target = File(File(item.path).parent, File(item.path).nameWithoutExtension)
                                                            if (repository.unzip(File(item.path), target)) {
                                                                ServerEvents.refreshTrigger.value++
                                                                Toast.makeText(context, R.string.unzip_success, Toast.LENGTH_SHORT).show()
                                                            }
                                                        }
                                                    },
                                                    leadingIcon = { Icon(Icons.Default.Unarchive, null) }
                                                )
                                            }
                                            DropdownMenuItem(
                                                text = { Text(stringResource(R.string.delete)) },
                                                onClick = {
                                                    showMenu = false
                                                    scope.launch {
                                                        if (repository.delete(item.path)) {
                                                            ServerEvents.refreshTrigger.value++
                                                        }
                                                    }
                                                },
                                                leadingIcon = { Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error) }
                                            )
                                        }
                                    }
                                }
                            },
                            modifier = Modifier
                                .combinedClickable(
                                    onClick = { 
                                        if (isSelectMode) {
                                            toggleSelection(item.path)
                                        } else if (item.isDir) {
                                            currentPath = item.path 
                                        }
                                    },
                                    onLongClick = {
                                        if (!isSelectMode) {
                                            isSelectMode = true
                                            toggleSelection(item.path)
                                        }
                                    }
                                )
                                .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f) else Color.Transparent)
                        )
                    }

                    if (systemFiles.isNotEmpty()) {
                        item(key = "system_header") {
                            Text(
                                text = stringResource(R.string.system_files),
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }
                        items(systemFiles, key = { it.id }) { item ->
                            ListItem(
                                headlineContent = { Text(item.name) },
                                leadingContent = {
                                    Icon(
                                        imageVector = if (item.isDir) Icons.Default.Folder else Icons.Default.Description,
                                        contentDescription = null,
                                        modifier = Modifier.alpha(0.5f)
                                    )
                                },
                                modifier = Modifier.clickable { if (item.isDir) currentPath = item.path }.alpha(0.7f)
                            )
                        }
                    }
                }
            }
        }
    }
    
    val isRoot = volumes.any { it.path == currentPath }
    BackHandler(enabled = (currentPath.isNotEmpty() && !isRoot) || isSelectMode) {
        if (isSelectMode) {
            isSelectMode = false
            selectedPaths.clear()
        } else {
            currentPath = File(currentPath).parent ?: currentPath
        }
    }
}

@Composable
fun ServerScreen(repository: MediaRepository) {
    val context = LocalContext.current
    val volumes = remember { repository.getStorageVolumes() }
    val transfers = ServerEvents.activeTransfers
    val isPlaying by ServerEvents.isPlaying
    val currentPath by ServerEvents.currentPlayingPath

    var isRunning by remember { mutableStateOf(HttpServerService.isRunning(context)) }
    val ipAddress = remember { HttpServerService.getIpAddress() }
    val serverUrl = "http://$ipAddress:9000"
    val qrBitmap = remember(serverUrl) { generateQrCode(serverUrl) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(stringResource(R.string.storage_capacity), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(8.dp))
        
        volumes.forEach { volume ->
            StorageCapacityCard(volume)
            Spacer(modifier = Modifier.height(8.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = if (isRunning) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (!isRunning) {
                    Text(stringResource(R.string.server_stopped), style = MaterialTheme.typography.bodyMedium)
                } else if (transfers.isEmpty() && !isPlaying) {
                    Text(stringResource(R.string.server_running), style = MaterialTheme.typography.bodyMedium)
                } else {
                    if (transfers.isNotEmpty()) {
                        val current = transfers.first()
                        Text(
                            text = stringResource(R.string.client_transferring, current.client, current.type),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = current.fileName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            textAlign = TextAlign.Center
                        )
                        if (transfers.size > 1) {
                            Text(stringResource(R.string.other_tasks_count, transfers.size - 1, transfers.size), fontSize = 11.sp)
                        }
                    }
                    
                    if (isPlaying && currentPath != null) {
                        if (transfers.isNotEmpty()) Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = stringResource(R.string.server_playing_music),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Text(
                            text = File(currentPath!!).name,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            if (isRunning && qrBitmap != null) {
                Box(modifier = Modifier.size(180.dp).clip(RoundedCornerShape(12.dp)).background(Color.White).padding(12.dp)) {
                    Image(bitmap = qrBitmap.asImageBitmap(), contentDescription = "QR", modifier = Modifier.fillMaxSize())
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(serverUrl, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                modifier = Modifier.fillMaxWidth().height(56.dp),
                onClick = {
                    val intent = Intent(context, HttpServerService::class.java)
                    if (!isRunning) context.startForegroundService(intent) else context.stopService(intent)
                    isRunning = !isRunning
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isRunning) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                )
            ) {
                Text(if (isRunning) stringResource(R.string.stop_server) else stringResource(R.string.start_server))
            }
        }
    }
}

fun generateQrCode(text: String): Bitmap? {
    return try {
        val size = 512
        val bitMatrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
        val bitmap = createBitmap(size, size, Bitmap.Config.RGB_565)
        for (x in 0 until size) {
            for (y in 0 until size) {
                bitmap[x, y] = if (bitMatrix.get(x, y)) android.graphics.Color.BLACK else android.graphics.Color.WHITE
            }
        }
        bitmap
    } catch (_: Exception) {
        null
    }
}
